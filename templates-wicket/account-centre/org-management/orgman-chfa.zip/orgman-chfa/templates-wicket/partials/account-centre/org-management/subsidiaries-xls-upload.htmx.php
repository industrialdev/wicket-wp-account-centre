<?php
// No direct access.
defined('ABSPATH') || die('No direct access.');

/**
 * Verifying nonce with sanitizing as per WPCS.
 * https://developer.wordpress.org/news/2023/08/01/understand-and-use-wordpress-nonces-properly/
 *
 * nonce action: wicket-acc-orgman-childorgs-xls
 * nonce name: nonce
 */
if (!isset($_POST['nonce'])) {
  die(__('You do not have sufficient permissions to access this page.', 'wicket-acc'));
}

if (! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'wicket-acc-orgman-childorgs-xls')) {
  die(__('You do not have sufficient permissions to access this page.', 'wicket-acc'));
}

$postData  = $_POST;
$filesData = $_FILES;

// Check if minimum data is present
if($postData['action'] !== 'wicket-acc-orgman-childorgs-xls') {
  die(__('Invalid action', 'wicket-acc'));
}

if (!isset($postData['userId']) || !isset($postData['action']) || !isset($filesData['fileUpload'])) {
  die(__('Missing data', 'wicket-acc'));
}

// Sanitize data
$userId = absint($postData['userId']);

// Get user information
$user = get_user_by('ID', $userId);
if (!$user) {
  die(__('User not found', 'wicket-acc'));
}

// Get file information
$file = $filesData['fileUpload']['tmp_name'];
if (!$file) {
  die(__('Missing file', 'wicket-acc'));
}

// Validate file type
if ($filesData['fileUpload']['type'] !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
  die(__('Invalid file type', 'wicket-acc'));
}

// Upload the file
$year  = date('Y');
$month = date('m');
$uploads_path = WICKET_ACC_UPLOADS_PATH . 'subsidiaries/' . $year . '/' . $month . '/';
$file_name = $filesData['fileUpload']['name'];
$file_path = $uploads_path . $file_name;

// Create the directory if it doesn't exist
if (!file_exists($uploads_path)) {
  wp_mkdir_p($uploads_path);
}

// Upload the file
if (!move_uploaded_file($file, $file_path)) {
  die(__('File upload failed', 'wicket-acc'));
}

// Send the email
$emailDestinatary = get_option('admin_email');
$emailData = [
  'headers'     => ['Content-Type: text/html; charset=UTF-8'],
  'to'          => $emailDestinatary,
  'to_name'     => get_option('blogname'),
  'first_name'  => $user->first_name,
  'last_name'   => $user->last_name,
  'email'       => $user->user_email,
  'attachments' => $file_path,
  'subject'     => __('Child Organization Subsidiaries Upload', 'wicket-acc'),
  'message'     => wp_sprintf(__('<p>Hi!</p><p>User %s %s (%s) has requested to create subsidiaries for %s</p><p>Spreadsheet attached.</p><p>Automated message from %s</p>', 'wicket-acc'), $user->first_name, $user->last_name, $user->user_email, get_option('blogname'), get_option('blogname')),
];

wp_mail($emailData['to'], $emailData['subject'], $emailData['message'], $emailData['headers'], $emailData['attachments']);

// Delete the uploaded file
unlink($file_path);
?>
<!-- Success Message -->
<div class="alert alert-success d-flex align-items-center p-3 my-4" role="alert">
  <i class="fas fa-check-circle me-3"></i>
  <div>
    <strong><?php esc_html_e('File successfully uploaded', 'wicket-acc'); ?></strong>
    <p class="mb-0"><?php esc_html_e('CHFA will contact you once the locations / banners / subsidiaries have been added.', 'wicket-acc'); ?></p>
  </div>
</div>
