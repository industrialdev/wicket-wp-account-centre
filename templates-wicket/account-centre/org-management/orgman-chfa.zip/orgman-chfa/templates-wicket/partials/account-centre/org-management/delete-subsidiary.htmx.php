<?php
// No direct access.
defined('ABSPATH') || die('No direct access.');

/**
 * Verifying nonce with sanitizing as per WPCS.
 * https://developer.wordpress.org/news/2023/08/01/understand-and-use-wordpress-nonces-properly/
 *
 * nonce action: wicket-acc-orgman-childorgs-xls
 * nonce name: nonce
 */
if (!isset($_POST['nonce'])) {
  die(__('You do not have sufficient permissions to access this page.', 'wicket-acc'));
}

if (! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'wicket-acc-orgman-delete-childorg')) {
  die(__('You do not have sufficient permissions to access this page.', 'wicket-acc'));
}

// Validate action
if ($_POST['action'] !== 'wicket-acc-orgman-delete-childorg') {
  die(__('Invalid action', 'wicket-acc'));
}

$postData = $_POST;

// Validate minimum required data
if (!isset($postData['userId']) || !isset($postData['child_org_id']) || !isset($postData['org_id']) || !isset($postData['postId'])) {
  die(__('Missing data', 'wicket-acc'));
}

// Sanitize data
$postData['child_org_id'] = sanitize_text_field(wp_unslash($postData['child_org_id']));

// Delete child org
$deleted = wicket_orgman_delete_organization($postData['child_org_id']);

if (!$deleted) {
  ?>
  <div id="response-message" class="alert alert-error mt-4" role="alert">
    <p>
      <?php
      echo __('Error deleting the organization. Please, try again or contact support.', 'wicket-acc');
      ?>
    </p>
  </div>
  <?php
} else {
  // Redirect, quick and dirty
  $current_page = wicket_orgman_get_page_url('subsidiaries', true);
  // We don't know if the URL will be a pretty one or not. Let's add the org_id considering this.
  $redirect_url = add_query_arg('org_id', $postData['org_id'], $current_page);
  ?>
  <div id="response-message" class="alert alert-success mt-4" role="alert">
    <p>
      <?php
      echo __('Organization deleted successfully.', 'wicket-acc');
      echo '<br>';
      echo __('Redirecting in 5 seconds...', 'wicket-acc');
      ?>
    </p>
  </div>
  <!-- Yes: styles, scripts and html tags will parsed by the browser once they are rendered. Cool, ah? -->
  <style>
    #acc-remove-childorg {
      display: none !important
    }
  </style>
  <meta http-equiv="refresh" content="5; url='<?php echo $redirect_url; ?>'" />
  <?php
}
