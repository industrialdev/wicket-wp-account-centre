<?php
// No direct access.
defined('ABSPATH') || die('No direct access.');

/**
 * Verifying nonce with sanitizing as per WPCS.
 * https://developer.wordpress.org/news/2023/08/01/understand-and-use-wordpress-nonces-properly/
 *
 * nonce action: wicket-acc-orgman-business-docs-upload
 * nonce name: nonce
 */
if (!isset($_POST['nonce'])) {
  die(__('You do not have sufficient permissions to access this page.', 'wicket-acc'));
}

if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'wicket-acc-orgman-business-docs-upload')) {
  die(__('Invalid nonce', 'wicket-acc'));
}

// Validate action
if (!isset($_POST['action']) || $_POST['action'] !== 'wicket-acc-orgman-business-docs-upload') {
  die(__('Invalid action', 'wicket-acc'));
}

if (!isset($_POST['org_id'])) {
?>
  <div class="htmx-response alert alert-danger mt-5" role="alert">
    <?php esc_html_e('Organization ID is required', 'wicket-acc'); ?>
  </div>
<?php
  exit;
}

/*
array(3) { ["action"]=> string(38) "wicket-acc-orgman-business-docs-upload" ["nonce"]=> string(10) "b0aaf79d91" ["org_id"]=> string(36) "51f22eea-c473-4400-aa51-685ea957a983" }

array(1) { ["fileUpload"]=> array(6) { ["name"]=> array(2) { [0]=> string(9) "dummy.pdf" [1]=> string(9) "dummy.xml" } ["full_path"]=> array(2) { [0]=> string(9) "dummy.pdf" [1]=> string(9) "dummy.xml" } ["type"]=> array(2) { [0]=> string(15) "application/pdf" [1]=> string(8) "text/xml" } ["tmp_name"]=> array(2) { [0]=> string(14) "/tmp/phpVJapLX" [1]=> string(14) "/tmp/phpwiU5ld" } ["error"]=> array(2) { [0]=> int(0) [1]=> int(0) } ["size"]=> array(2) { [0]=> int(18042) [1]=> int(613) } } }
*/

// Any file?
if (!isset($_FILES['fileUpload']) || empty($_FILES['fileUpload']['name'])) {
?>
  <div class="htmx-response alert alert-danger mt-5" role="alert">
    <?php esc_html_e('No file selected', 'wicket-acc'); ?>
  </div>
<?php
  exit;
}

// Set our data
$org_id      = sanitize_text_field(wp_unslash($_POST['org_id']));
$upload_path = WICKET_ACC_UPLOADS_PATH . 'organization-docs/';
$upload_url  = WICKET_ACC_UPLOADS_URL . 'organization-docs/';
$upload_org_folder_path = $upload_path . $org_id;
$upload_org_folder_url  = $upload_url . $org_id;

// Create the directory if it doesn't exist
if (!file_exists($upload_path)) {
  wp_mkdir_p($upload_path);
}

// Create a sub-folder with organization ID as name
if (!file_exists($upload_org_folder_path)) {
  wp_mkdir_p($upload_org_folder_path);
}

// Any existing files inside the folder? delete them
if ($existing_files = glob($upload_org_folder_path . '/*')) {
  foreach ($existing_files as $file) {
    if (is_file($file)) {
      unlink($file);
    }
  }
}

// Upload all the files received
$filesUploaded = [];
foreach ($_FILES['fileUpload']['name'] as $i => $filename) {
  if (0 === $_FILES['fileUpload']['error'][$i]) {
    $file = [
      'name'     => $filename,
      'type'     => $_FILES['fileUpload']['type'][$i],
      'tmp_name' => $_FILES['fileUpload']['tmp_name'][$i],
      'error'    => $_FILES['fileUpload']['error'][$i],
      'size'     => $_FILES['fileUpload']['size'][$i],
    ];

    $filename  = sanitize_file_name($filename);
    $file_path = $upload_org_folder_path . '/' . $filename;

    if (move_uploaded_file($file['tmp_name'], $file_path)) {
      $filename_no_ext = ucfirst(pathinfo($filename, PATHINFO_FILENAME));
      $filename_no_ext = str_replace('-', ' ', $filename_no_ext);
      $filename_no_ext = str_replace('_', ' ', $filename_no_ext);

      $filesUploaded[] = [
        'internalnote'  => $filename_no_ext,
        'requireddoc'   => $upload_org_folder_url . '/' . $filename
      ];
    }
  }
}

// No files uploaded?
if (count($filesUploaded) === 0) {
?>
  <div class="htmx-response alert alert-danger mt-5" role="alert">
    <?php esc_html_e('No files uploaded', 'wicket-acc'); ?>
  </div>
  <?php
  exit;
}

// If we have files uploaded, send them to the MDP
if (count($filesUploaded) > 0) {
  /**
   * PATCH:
   * https://chfa-admin.staging.wicketcloud.com/api/organizations/51f22eea-c473-4400-aa51-685ea957a983
   *
   * Payload example:
   * {"data":{"type":"organizations","attributes":{"data_fields":[{"$schema":"urn:uuid:6ec17e5a-7d3e-4106-9060-d96cdfa39ab6","version":1,"value":{"orgdocrepeat":[{"requireddoc":"https://www.google.com/this.pdf","internalnote":"Dummy fake PDF"},{"requireddoc":"https://www.bing.com/that.pdf","internalnote":"Dummy PDF, fake URL"},{"requireddoc":"https://www.bing.com/acuya.pdf","internalnote":"Acuyá"}]}}]},"id":"51f22eea-c473-4400-aa51-685ea957a983"}}
   */

  $payload = [
    'data' => [
      'type' => 'organizations',
      'id' => $org_id,
      'attributes' => [
        'data_fields' => [
          [
            '$schema' => 'urn:uuid:6ec17e5a-7d3e-4106-9060-d96cdfa39ab6',
            //'version' => 1, // MDP API set this automatically
            'value' => [
              'orgdocrepeat' => $filesUploaded
            ]
          ]
        ]
      ]
    ]
  ];

  try {
    $client = WACC()->MdpApi->init_client();
    $client->patch("organizations/$org_id", ['json' => $payload]);
    ?>
    <div class="htmx-response alert alert-success mt-5" role="alert">
      <p><?php esc_html_e('Documents uploaded successfully.', 'wicket-acc'); ?></p>
      <p><?php esc_html_e('Refresh the page to see the changes, or wait for 5 seconds to be automatically redirected.', 'wicket-acc'); ?></p>
    </div>
    <script>
      document.addEventListener('htmx:afterSwap', () => {
        const dropZone = document.getElementById('dropZone');
        const fileList = document.getElementById('fileList');
        if (dropZone) dropZone.classList.remove('has-files');
        if (fileList) fileList.innerHTML = '';
        document.querySelectorAll('.documents-upload__file-remove').forEach(button => button.click());
      });

      setTimeout(() => {
        window.location.reload();
      }, 5000);
    </script>
  <?php
  } catch (Exception $e) {
    ?>
    <div class="htmx-response alert alert-danger mt-5" role="alert">
      <?php esc_html_e('Error uploading documents', 'wicket-acc'); ?>
      <br>
      <code>
        <?php echo esc_html($e->getMessage()); ?>
      </code>
    </div>
    <?php
    exit;
  }
}
