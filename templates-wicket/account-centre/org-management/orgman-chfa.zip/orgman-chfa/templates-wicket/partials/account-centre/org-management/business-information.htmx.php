<?php
// No direct access.
defined('ABSPATH') || die('No direct access.');

/**
 * Verifying nonce with sanitizing as per WPCS.
 * https://developer.wordpress.org/news/2023/08/01/understand-and-use-wordpress-nonces-properly/
 *
 * nonce action: wicket-acc-orgman-business-info
 * nonce name: nonce
 */
if (!isset($_POST['nonce'])) {
  die(__('You do not have sufficient permissions to access this page.', 'wicket-acc'));
}

if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'wicket-acc-orgman-business-info')) {
  die(__('Invalid nonce', 'wicket-acc'));
}

// Validate action
if (!isset($_POST['action']) || $_POST['action'] !== 'wicket-acc-orgman-business-info') {
  die(__('Invalid action', 'wicket-acc'));
}

if (!isset($_POST['org_id'])) {
?>
  <div class="htmx-response alert alert-danger mt-5" role="alert">
    <?php esc_html_e('Organization ID is required', 'wicket-acc'); ?>
  </div>
  <?php
  exit;
}

$org_id = sanitize_text_field($_POST['org_id']);
$lang   = defined('ICL_LANGUAGE_CODE') ? ICL_LANGUAGE_CODE : 'en';

// Initialize common payload structure
$base_payload = [
  'data' => [
    'type' => 'organizations',
    'attributes' => [
      'data_fields' => [
        [
          'value' => []
        ]
      ]
    ],
    'id' => "$org_id" // org_id NEEDS to be in quotes!
  ]
];

$success_count  = 0;
$error_messages = [];

// Process company attributes
$payload = $base_payload;
$payload['data']['attributes']['data_fields'][0]['$schema'] = 'urn:uuid:92112b20-bf2f-4939-a6ba-3c111ca96aeb';
$payload['data']['attributes']['data_fields'][0]['value']['attributes'] = (isset($_POST['company-attributes']) && is_array($_POST['company-attributes']))
  ? array_values($_POST['company-attributes'])
  : [];

// Add the "other" text for company attributes if it exists
if (isset($_POST['company-attributes_other']) && !empty($_POST['company-attributes_other'])) {
  $payload['data']['attributes']['data_fields'][0]['value']['attributesother'] = $_POST['company-attributes_other'];
}

$result = wicket_orgman_business_info_send_section_patch($org_id, $payload);
if (is_array($result) && isset($result['error'])) {
  $error_messages[] = __('Failed to update company attributes', 'wicket-acc') . ': ' . $result['error'];
} else if ($result) {
  $success_count++;
}

// Process certifications
$payload = $base_payload;
$payload['data']['attributes']['data_fields'][0]['$schema'] = 'urn:uuid:aa869490-1415-4dfa-8f25-1a590d841fe4';
$payload['data']['attributes']['data_fields'][0]['value']['certifications'] = (isset($_POST['certifications']) && is_array($_POST['certifications']))
  ? array_values($_POST['certifications'])
  : [];

// Add the "other" text if it exists
if (isset($_POST['certifications_other']) && !empty($_POST['certifications_other'])) {
  $payload['data']['attributes']['data_fields'][0]['value']['certificationsother'] = $_POST['certifications_other'];
}

$result = wicket_orgman_business_info_send_section_patch($org_id, $payload);
if (is_array($result) && isset($result['error'])) {
  $error_messages[] = __('Failed to update certifications', 'wicket-acc') . ': ' . $result['error'];
} else if ($result) {
  $success_count++;
}

// Process business services
$payload = $base_payload;
$payload['data']['attributes']['data_fields'][0]['$schema'] = 'urn:uuid:63304035-7b3b-473e-8fb4-6b00f97e716d';
$payload['data']['attributes']['data_fields'][0]['value']['services'] = (isset($_POST['business-services']) && is_array($_POST['business-services']))
  ? array_values($_POST['business-services'])
  : [];

// Add the "other" text for business services if it exists
if (isset($_POST['business-services_other']) && !empty($_POST['business-services_other'])) {
  $payload['data']['attributes']['data_fields'][0]['value']['servicesother'] = $_POST['business-services_other'];
}

$result = wicket_orgman_business_info_send_section_patch($org_id, $payload);
if (is_array($result) && isset($result['error'])) {
  $error_messages[] = __('Failed to update business services', 'wicket-acc') . ': ' . $result['error'];
} else if ($result) {
  $success_count++;
}

// Process product_segments
$payload = $base_payload;
$payload['data']['attributes']['data_fields'][0]['$schema'] = 'urn:uuid:868b4e5e-7b22-48cc-bb55-5a729cb89111';
$payload['data']['attributes']['data_fields'][0]['value']['prodoptions'] = (isset($_POST['product-segments']) && is_array($_POST['product-segments']))
  ? array_values($_POST['product-segments'])
  : [];

// Add the "other" text for product segments if it exists
if (isset($_POST['product-segments_other']) && !empty($_POST['product-segments_other'])) {
  $payload['data']['attributes']['data_fields'][0]['value']['segmentsother'] = $_POST['product-segments_other'];
}

$result = wicket_orgman_business_info_send_section_patch($org_id, $payload);
if (is_array($result) && isset($result['error'])) {
  $error_messages[] = __('Failed to update product segments', 'wicket-acc') . ': ' . $result['error'];
} else if ($result) {
  $success_count++;
}

// Display results
if (!empty($error_messages)) {
  foreach ($error_messages as $error) {
  ?>
    <div class="htmx-response alert alert-danger mt-5" role="alert">
      <?php echo esc_html($error); ?>
    </div>
  <?php
  }
} else {

  // Check if one of them has changed. current_totalcdnrev vs totalcdnrev OR current_totalglobrev vs totalglobrev
  if (absint($_POST['current_totalcdnrev']) !== absint($_POST['totalcdnrev']) || absint($_POST['current_totalglobrev']) !== absint($_POST['totalglobrev'])) {
    // Let's send an email notification to the admin
    $email_data = [
      'org_id'        => $org_id,
      'totalcdnrev'   => $_POST['totalcdnrev'],
      'totalglobrev'  => $_POST['totalglobrev'],
      'current_totalcdnrev'  => $_POST['current_totalcdnrev'],
      'current_totalglobrev' => $_POST['current_totalglobrev'],
      'lang'          => $lang,
      'subject'       => __('CDN and Global Revenue updated', 'wicket-acc'),
      'body'          => sprintf(__('The CDN and Global Revenue for %s has been updated.<p>Previous CDN Revenue: %s<br/>New CDN Revenue: %s<br/>Previous Global Revenue: %s<br/>New Global Revenue: %s</p>', 'wicket-acc'), get_the_title($org_id), $_POST['current_totalcdnrev'], $_POST['totalcdnrev'], $_POST['current_totalglobrev'], $_POST['totalglobrev']),
    ];

    // Signature
    $email_data['body'] .= '<br/><p>' . sprintf(__('Notice sent from %s', 'wicket-acc'), get_bloginfo('name')) . '</p>';

    wicket_orgman_send_email_notification($email_data);
  }

  ?>
  <div class="htmx-response alert alert-success mt-5" role="status">
    <?php esc_html_e('Business information updated successfully', 'wicket-acc'); ?>
  </div>
<?php
}
