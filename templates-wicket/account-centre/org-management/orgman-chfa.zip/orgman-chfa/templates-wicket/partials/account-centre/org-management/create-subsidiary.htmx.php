<?php
// No direct access.
defined('ABSPATH') || die('No direct access.');

/**
 * Verifying nonce with sanitizing as per WPCS.
 * https://developer.wordpress.org/news/2023/08/01/understand-and-use-wordpress-nonces-properly/
 *
 * nonce action: wicket-acc-orgman-childorgs-xls
 * nonce name: nonce
 */
if (!isset($_POST['nonce'])) {
  die(__('You do not have sufficient permissions to access this page.', 'wicket-acc'));
}

if (! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'wicket-acc-orgman-create-childorg')) {
  die(__('You do not have sufficient permissions to access this page.', 'wicket-acc'));
}

$postData  = $_POST;

// Check if minimum data is present
if ($postData['action'] !== 'wicket-acc-orgman-create-childorg') {
  die(__('Invalid action', 'wicket-acc'));
}

if (!isset($postData['userId']) || !isset($postData['action']) || !isset($postData['parent_org'])) {
  die(__('Missing data', 'wicket-acc'));
}

// Sanitize data
$userId              = absint($postData['userId']);
$userUuid            = sanitize_text_field(wp_unslash($postData['userUuid']));
$parentOrg           = sanitize_text_field(wp_unslash($postData['parent_org']));
$childorgName        = sanitize_text_field(wp_unslash($postData['name']));
$childorgDescription = sanitize_text_field(wp_unslash($postData['description']));
$childorgType        = sanitize_text_field(wp_unslash($postData['type']));
$has_errors          = false;
$errors              = [];
$parentOrgOwner      = null;
$childOrg            = null;

$childorgEmail   = sanitize_text_field(wp_unslash($postData['email']));
$childorgPhone   = sanitize_text_field(wp_unslash($postData['phone']));
$childorgWebsite = sanitize_text_field(wp_unslash($postData['website']));

$childorgAddressCompany    = sanitize_text_field(wp_unslash($postData['company']));
$childorgAddressDepartment = sanitize_text_field(wp_unslash($postData['department']));
$childorgAddressDivision   = sanitize_text_field(wp_unslash($postData['division']));
$childorgAddressStreet     = sanitize_text_field(wp_unslash($postData['street']));
$childorgAddressSuite      = sanitize_text_field(wp_unslash($postData['suite']));
$childorgAddressCity       = sanitize_text_field(wp_unslash($postData['city']));
$childorgAddressCountry    = sanitize_text_field(wp_unslash($postData['country']));
$childorgAddressProvince   = sanitize_text_field(wp_unslash($postData['province']));
$childorgAddressPostal     = sanitize_text_field(wp_unslash($postData['postal']));

// Get user information
$user = get_user_by('ID', $userId);
if (!$user) {
  die(__('User not found', 'wicket-acc'));
}

// Parent organization owner
$parentOrgOwner = wicket_orgman_get_organization_owner($parentOrg);

/*if (!$parentOrgOwner) {
  $has_errors = true;
  $errors[] = __('Failed to get parent organization owner', 'wicket-acc');
}*/

if (!$has_errors) {
  // Create child org
  $childOrg = wicket_create_organization($childorgName, $childorgType, [], $parentOrg);

  if (!$childOrg) {
    $has_errors = true;
    $errors[] = __('Failed to create child organization', 'wicket-acc');
  }
}

if (!$has_errors && $childOrg) {
  // Add security roles to the user: owner, membership_manager, org_editor
  wicket_orgman_assign_roles($userUuid, ['owner', 'membership_manager', 'org_editor'], $childOrg['data']['id']);

  // Add security roles to the parent organization owner: membership_manager, org_editor
  // Only if $userUuid != $parentOrgOwner->id
  if ($parentOrgOwner !== null && $userUuid != $parentOrgOwner->id) {
    wicket_orgman_assign_roles($parentOrgOwner->id, ['membership_manager', 'org_editor'], $childOrg['data']['id']);
  }

  // Description
  wicket_set_organization_info($childOrg['data']['id'], [
    'data' => [
      'type' => 'organizations',
      'id'   => $childOrg['data']['id'],
      'attributes' => [
        'description'    => $childorgDescription,
        'description_en' => $childorgDescription
      ]
    ]
  ]);

  // Address
  wicket_create_organization_address($childOrg['data']['id'], [
    'data' => [
      'type' => 'addresses',
      'attributes' => [
        'type' => 'general',
        'company_name'    => $childorgAddressCompany,
        'department'      => $childorgAddressDepartment,
        'division'        => $childorgAddressDivision,
        'address1'        => $childorgAddressStreet,
        'address2'        => $childorgAddressSuite,
        'city'            => $childorgAddressCity,
        'country_code'    => $childorgAddressCountry,
        'state_name'      => $childorgAddressProvince,
        'zip_code'        => $childorgAddressPostal
      ]
    ]
  ]);

  // Email
  wicket_create_organization_email($childOrg['data']['id'], [
    'data' => [
      'type' => 'emails',
      'attributes' => [
        'type'    => 'general',
        'address' => $childorgEmail
      ]
    ]
  ]);

  // Phone
  wicket_create_organization_phone($childOrg['data']['id'], [
    'data' => [
      'type' => 'phones',
      'attributes' => [
        'type'   => 'general',
        'number' => $childorgPhone
      ]
    ]
  ]);

  // Website
  wicket_create_organization_web_address($childOrg['data']['id'], [
    'data' => [
      'type' => 'web_addresses',
      'attributes' => [
        'type'    => 'website',
        'address' => $childorgWebsite
      ]
    ]
  ]);
}

// Success message
if ($has_errors) {
?>
  <div id="response-message" class="alert alert-error" role="alert">
    <p>
      <strong><?php esc_html_e('Error!', 'wicket'); ?></strong>
    <ul>
      <?php
      foreach ($errors as $error) {
        echo '<li>' . esc_html($error) . '</li>';
      }
      ?>
    </ul>
    </p>
  </div>
<?php
} else {
?>
  <div id="response-message" class="alert alert-success" role="alert">
    <p>
      <strong><?php esc_html_e('Success!', 'wicket'); ?></strong> <?php printf(esc_html__('Child Organization %s has been created.', 'wicket'), esc_html($childorgName)); ?>
    </p>
  </div>
<?php
}
