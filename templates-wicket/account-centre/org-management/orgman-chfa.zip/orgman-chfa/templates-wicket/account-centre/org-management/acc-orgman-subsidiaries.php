<?php

namespace WicketAcc;

// No direct access
defined('ABSPATH') || exit;

/**
 * Template Name: ACC Org-Management Child Orgs
 * Template Post: my-account
 *
 * Locations / Banners / Subsidiaries
 */

wicket_orgman_page_role_check(
    [
        'administrator',
        'owner',
        'org_editor',
        'membership_manager',
    ]
);

global $wp, $orgman_pages_slugs, $orgman_pages_url;

$client = WACC()->MdpApi->init_client();
$person = wicket_orgman_get_current_person();
$lang   = defined('ICL_LANGUAGE_CODE') ? ICL_LANGUAGE_CODE : 'en';

// Get parent page slug
$current_page     = get_post();
$parent_page_slug = get_post($current_page->post_parent)->post_name;

/**------------------------------------------------------------------
 * Decide whether we are loading an ORG from the URL
 * or looking up all associated orgs to person
 * if there's more than 1, we list them for the user to choose
 * which org they want to see
------------------------------------------------------------------*/
$org_id = $_GET['org_id'] ?? '';

if ($org_id) {
    $org = wicket_get_organization($org_id);
} else {
    $org_ids = [];

    if (is_null($person)) {
        wp_die(__('Person not found. Contact your administrator', 'wicket-acc'));
    }

    // Figure out orgs I should see. This association to the org is set on each role. The actual role types we look at might change depending on the project
    foreach ($person->included() as $person_included) {
        // Warning fix
        if (!isset($person_included['attributes']['name'])) {
            $person_included['attributes']['name'] = '';
        }

        // Assigned roles
        $roles = $person_included['attributes']['assignable_role_names'] ?? [];

        if (
            $person_included['type'] == 'roles' && stristr($person_included['attributes']['name'], 'owner')
            || stristr($person_included['attributes']['name'], 'membership_manager')
            || stristr($person_included['attributes']['name'], 'org_editor')
            || isset(
                $person_included['attributes']['assignable_role_names']
            ) && (
                in_array('membership_manager', $roles)
                || in_array('org_editor', $roles)
            )
        ) {
            if (isset($person_included['relationships']['resource']['data']['id']) && $person_included['relationships']['resource']['data']['type'] == 'organizations') {
                $org_ids[] = $person_included['relationships']['resource']['data']['id'];
            }
        }
    }

    $org_ids = array_unique($org_ids);

    // If they only have 1 org, redirect back to this page with the org ID in the URL to show info for that org. Ese we build a list of their orgs below to choose from
    if (count($org_ids) == 1) {
        $url = strtok($_SERVER["REQUEST_URI"], '?');
        header('Location: ' . $url . '?org_id=' . $org_ids[0]);
        die;
    }

    // In this page, we need to get the parent org ID, and redirect the user to this page with the parent org ID in the URL
    if (count($org_ids) > 1) {
        $url = strtok($_SERVER["REQUEST_URI"], '?');
        header('Location: ' . $url . '?org_id=' . $org_ids[0]);
        die;
    }
}

get_header();
?>

<?php
$wrapper_classes     = [];
$dev_wrapper_classes = get_field('page_wrapper_class');
if (!empty($dev_wrapper_classes)) {
    $wrapper_classes[] = $dev_wrapper_classes;
}

// Class for Roster Managment styling
$wrapper_classes[] = 'wicket-acc';
$wrapper_classes[] = 'roster-management';
$wrapper_classes[] = 'wicket-acc-container';
$wrapper_classes[] = 'acc-organization-management';
$wrapper_classes[] = 'wicket-acc-orgman-childorgs';

$display_breadcrumb   = get_field('display_breadcrumb');
$display_publish_date = get_field('display_publish_date');
?>

<?php
WACC()->renderGlobalSubHeader();
?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

        <?php
        if ($display_breadcrumb) {
            echo '<div class="wp-block-breadcrumbs">'; // Having the `wp-block-` prefix will help align it with the other Blocks
            get_component('breadcrumbs', []);
            echo '</div>';
        }
        if ($display_publish_date) {
            echo '<div class="wp-block-published-date">';
            echo "<p class='mt-3 mb-4'><strong>" . __('Published:', 'wicket-acc') . ' ' . get_the_date('d-m-Y') . "</strong></p>";
            echo '</div>';
        }
        ?>

        <main
            class="<?php echo implode(' ', $wrapper_classes) ?> container mb-8"
            id="main-content">

            <section id="content" class="woocommerce-wicket--container section page-default">
                <div class="wicket-acc-page woocommerce-wicket--account-centre row">
                    <?php the_content(); ?>

                    <div class="container my-4">

                        <?php
                        if ($org_id) :
                            $org_info = wicket_orgman_get_organization_info_extended($org_id, $lang);

                            if (!$org_info) {
                                wp_die(__('Organization info not found', 'wicket-acc'));
                            }
                        ?>

                            <!-- Your Business Section -->
                            <div class="card border rounded p-3">
                                <div class="card-header"><?php echo $org_info['org_name'] ?></div>
                                <div class="card-body">
                                    <?php if (isset($org_info['org_meta']['main_address']['formatted_address_label']) && !empty($org_info['org_meta']['main_address']['formatted_address_label'])) : ?>
                                        <p class="location-name">
                                            <?php echo $org_info['org_meta']['main_address']['formatted_address_label']; ?>
                                        </p>
                                    <?php endif; ?>
                                    <div class="d-flex gap-2">
                                        <a href="<?php echo $orgman_pages_url['profile']; ?>" aria-label="Edit Business Profile">
                                            <?php _e('Edit Business Profile', 'wicket-acc'); ?>
                                        </a>
                                        <a href="<?php echo $orgman_pages_url['profile']; ?>" aria-label="Edit Business Information">
                                            <?php _e('Edit Business Information', 'wicket-acc'); ?>
                                        </a>
                                        <a href="<?php echo $orgman_pages_url['members']; ?>" aria-label="Manage Members">
                                            <?php _e('Manage Members', 'wicket-acc'); ?>
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <?php
                            $child_organizations = wicket_orgman_get_child_organizations($org_id);
                            ?>
                            <!-- Your Locations / Banners / Subsidiaries Section -->
                            <div class="card border rounded p-3">
                                <div class="card-header"><?php _e('Your Locations / Banners / Subsidiaries', 'wicket-acc'); ?></div>
                                <div class="card-body">
                                    <?php
                                    if (!is_array($child_organizations)) {
                                    ?>
                                        <p>
                                            <?php _e('No Locations / Banners / Subsidiaries found', 'wicket-acc'); ?>
                                        </p>
                                    <?php
                                    } else {
                                    ?>
                                        <p class="location-count"><?php _e('Number of Locations:', 'wicket-acc'); ?> <strong><?php echo $child_organizations['meta']['page']['total_items']; ?></strong></p>
                                        <hr class="mt-2 mb-4">

                                        <?php
                                        foreach ($child_organizations['data'] as $child_org) {
                                        ?>
                                            <!-- Location 1 -->
                                            <div class="mt-3 mb-3">
                                                <p class="location-name"><?php echo $child_org['attributes']['legal_name']; ?></p>

                                                <?php
                                                if (wicket_orgman_role_check(['administrator', 'org_editor', 'membership_manager'])) {
                                                ?>
                                                    <div class="d-flex gap-2">
                                                        <a href="<?php echo $orgman_pages_url['profile']; ?>&child_org_id=<?php echo $child_org['id']; ?>" aria-label="<?php _e('Edit Business Profile', 'wicket-acc'); ?>"><?php _e('Edit Business Profile', 'wicket-acc'); ?></a>
                                                        <a href="<?php echo $orgman_pages_url['profile']; ?>&child_org_id=<?php echo $child_org['id']; ?>" aria-label="<?php _e('Edit Business Information', 'wicket-acc'); ?>"><?php _e('Edit Business Information', 'wicket-acc'); ?></a>
                                                        <a href="<?php echo $orgman_pages_url['members']; ?>&child_org_id=<?php echo $child_org['id']; ?>" aria-label="<?php _e('Manage Members', 'wicket-acc'); ?>"><?php _e('Manage Members', 'wicket-acc'); ?></a>
                                                    </div>
                                                <?php
                                                }
                                                ?>
                                            </div>
                                            <hr>
                                    <?php
                                        }
                                    }
                                    ?>

                                </div>
                            </div>

                            <?php
                            if (wicket_orgman_role_check(['administrator', 'childorg_manager'])) {
                            ?>
                                <!-- Add a Location Button -->
                                <div class="d-flex justify-content-start mt-4">
                                    <a class="button button--primary" aria-label="<?php _e('Add a Location', 'wicket-acc'); ?>" href="<?php echo $orgman_pages_url['subsidiaries-add-new']; ?>"><?php _e('Add a Location', 'wicket-acc'); ?></a>
                                </div>
                            <?php
                            }
                            ?>

                        <?php
                        else :

                            if ($org_ids) {
                                echo "<h2 class='primary_link_color'>" . __('Choose an Organization:', 'wicket-acc') . "</h2>";
                                echo "<ul>";
                                // lookup org details based on UUID found on the role
                                foreach ($org_ids as $org_uuid) {
                                    $organization = $client->get("organizations/$org_uuid");
                                    echo "<li>";
                                    echo "<a class='primary_link_color' href='" . home_url(add_query_arg([], $wp->request)) . "/?org_id=$org_uuid'>";
                                    echo $organization['data']['attributes']['legal_name_' . $lang];
                                    echo "</a>";
                                    echo "</li>";
                                }
                                echo '</ul>';
                            } else {
                                echo "<p>" . __('You currently have no organizations to manage information for.', 'wicket-acc') . "</p>";
                            }

                        endif;
                        ?>
                    </div> <!-- .container -->
                </div>

                <?php WACC()->renderAccSidebar(); ?>
            </section>
        </main>
<?php endwhile;
endif; ?>

<?php get_footer(); ?>
