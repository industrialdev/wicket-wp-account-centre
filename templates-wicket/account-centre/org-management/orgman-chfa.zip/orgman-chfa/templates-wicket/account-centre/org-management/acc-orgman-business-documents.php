<?php

namespace WicketAcc;

wicket_orgman_page_role_check(
  [
    'administrator',
    'owner',
    'org_editor',
    'membership_manager',
    'user',
    'customer',
    'member',
  ]
);

// No direct access
defined('ABSPATH') || exit;

/**
 * Template Name: ACC Org-Management Business Documents
 * Template Post: my-account
 */

global $wp, $orgman_pages_slugs, $orgman_pages_url;

$client = WACC()->MdpApi->init_client();
$person = wicket_orgman_get_current_person();
$lang   = defined('ICL_LANGUAGE_CODE') ? ICL_LANGUAGE_CODE : 'en';

$environment = get_option('wicket_admin_settings_environment');

if (!$environment) {
  $environment[0] = 'dev';
}

$full_time_employees_schema = $environment[0] == 'prod' ? 'e981bd15-8ce1-402f-b3a8-8ebec40ce66d' : '3f986a58-0a25-4e7a-83aa-0ad8736da541';
$organization_stats_schema = $environment[0] == 'prod' ? '8870bae7-6ac6-4993-9031-fb90d4d772a5' : '79a7a472-a843-4605-ae6e-b5eb440cfde5';
$location_data_schema = $environment[0] == 'prod' ? '1766eaa6-e3d5-408c-a7cd-e221c496069b' : '746dee68-91ad-419d-9e67-6be64c63a98e';
$business_type_schema = $environment[0] == 'prod' ? '3bc5ec95-63f7-4e0f-89d3-2dc8acf2c241' : '29d74c5e-4620-409c-a521-b30a03c365ef';

/**------------------------------------------------------------------
 * Decide whether we are loading an ORG from the URL
 * or looking up all associated orgs to person
 * if there's more than 1, we list them for the user to choose
 * which org they want to see
------------------------------------------------------------------*/
$org_id       = isset($_REQUEST['org_id']) ? $_REQUEST['org_id'] : '';
$child_org_id = isset($_REQUEST['child_org_id']) ? $_REQUEST['child_org_id'] : '';

// Override org_id if child_org_id is set
$parent_org_id = $org_id;
$org_id = isset($_REQUEST['child_org_id']) ? $_REQUEST['child_org_id'] : $org_id;

if ($org_id) {
  $org = wicket_get_organization($org_id);
  $org_datafields = wicket_get_field_from_data_fields($org['data']['attributes']['data_fields'], 'orgbustype')['value'];

  // Get org Business Type
  $org_business_type = $org_datafields['bustype'];
} else {
  $org_ids = [];

  // Figure out orgs I should see. This association to the org is set on each role. The actual role types we look at might change depending on the project
  foreach ($person->included() as $person_included) {
    // Warning fix
    if (!isset($person_included['attributes']['name'])) {
      $person_included['attributes']['name'] = '';
    }

    // Assigned roles
    $roles = $person_included['attributes']['assignable_role_names'] ?? [];

    if (
      $person_included['type'] == 'roles' && stristr($person_included['attributes']['name'], 'owner')
      || stristr($person_included['attributes']['name'], 'membership_manager')
      || stristr($person_included['attributes']['name'], 'org_editor')
      || isset(
        $person_included['attributes']['assignable_role_names']
      ) && (
        in_array('membership_manager', $roles)
        || in_array('org_editor', $roles)
      )
    ) {

      if (isset($person_included['relationships']['resource']['data']['id']) && $person_included['relationships']['resource']['data']['type'] == 'organizations') {
        $org_ids[] = $person_included['relationships']['resource']['data']['id'];
      }
    }
  }

  $org_ids = array_unique($org_ids);

  // If they only have 1 org, redirect back to this page with the org ID in the URL to show info for that org. Ese we build a list of their orgs below to choose from
  if (count($org_ids) == 1) {
    $url = strtok($_SERVER["REQUEST_URI"], '?');
    header('Location: ' . $url . '?org_id=' . $org_ids[0]);
    die;
  }
}

get_header();
$wicket_user_id = wicket_current_person_uuid();
?>

<?php
$wrapper_classes     = [];
$dev_wrapper_classes = get_field('page_wrapper_class');
if (!empty($dev_wrapper_classes)) {
  $wrapper_classes[] = $dev_wrapper_classes;
}

// Class for Roster Managment styling
$wrapper_classes[] = 'wicket-acc';
$wrapper_classes[] = 'roster-management';
$wrapper_classes[] = 'acc-organization-management';
$wrapper_classes[] = 'wicket-acc-container';

$display_breadcrumb   = get_field('display_breadcrumb');
$display_publish_date = get_field('display_publish_date');
?>

<?php
WACC()->renderGlobalSubHeader();
?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

    <?php
    if ($display_breadcrumb) {
      echo '<div class="wp-block-breadcrumbs">'; // Having the `wp-block-` prefix will help align it with the other Blocks
      get_component('breadcrumbs', []);
      echo '</div>';
    }
    if ($display_publish_date) {
      echo '<div class="wp-block-published-date">';
      echo "<p class='mt-3 mb-4'><strong>" . __('Published:', 'wicket-acc') . ' ' . get_the_date('d-m-Y') . "</strong></p>";
      echo '</div>';
    }
    ?>

    <main
      class="<?php echo implode(' ', $wrapper_classes) ?> container mb-8"
      id="main-content">

      <section id="content" class="woocommerce-wicket--container section page-default">
        <div id="uploadResponse"></div>

        <div class="wicket-acc-page woocommerce-wicket--account-centre row mb-4">
          <div class="columns large-8 wicket-acc-orgman container">

            <?php the_content(); ?>

            <?php if ($org_id) : ?>

              <?php
              $org_info = wicket_orgman_get_organization_info_extended($org_id, $lang);
              if ($org_info):

                $required_docs = isset($orgman_business_docs_map[$org_business_type]) ? $orgman_business_docs_map[$org_business_type] : [];
              ?>
                <h2><?php echo $org_info['org_name']; ?> <?php esc_html_e('Business Documents', 'wicket-acc'); ?></h2>
              <?php
              endif;

              if (isset($required_docs) && !empty($required_docs)) {
              ?>
                <div class="wicket-acc-orgman-business-docs documents-list row m-0">
                  <div class="documents-upload border p-4 col-12 d-flex flex-column">
                    <h3><?php esc_html_e('Available Documents:', 'wicket-acc'); ?></h3>

                    <?php
                    $org_docs = wicket_orgman_get_organization_documents($org_id);

                    if ($org_docs) :
                    ?>
                      <ul id="current-docs-list">
                        <?php
                        foreach ($org_docs['orgdocrepeat'] as $doc) :
                          if(!isset($doc['internalnote']) && empty($doc['internalnote'])) {
                            // Can we get the name from the URL?
                            $doc['internalnote'] = basename($doc['requireddoc']);
                          }

                          $doc_name = str_ireplace('-', ' ', $doc['internalnote']);
                          $doc_url  = $doc['requireddoc'];
                        ?>
                          <li class="document mb-1">
                            <a href="<?php echo $doc_url; ?>"><?php echo $doc_name; ?></a>
                          </li>
                        <?php
                        endforeach;
                        ?>
                      </ul>
                    <?php
                    endif;
                    ?>
                  </div>
                </div>
              <?php
              }
              ?>


              <?php
              if (wicket_orgman_role_check(['administrator', 'org_editor'])):
              ?>
                <div class="wicket-acc-orgman-business-docs-upload wicket-acc-orgman-business-docs row my-4">
                  <form
                    class="business-docs-form"
                    id="business-docs-form"
                    enctype="multipart/form-data"
                    hx-encoding="multipart/form-data"
                    hx-post="<?php echo wicket_orgman_htmx_url(); ?>?to=account-centre/org-management/business-docs-upload"
                    hx-target="#business-docs-form-response"
                    hx-on::after-request="this.reset()"
                    hx-swap="innerHTML transition:true"
                    hx-disabled-elt="this"
                    hx-ext="loading-states">
                    <input type="hidden" name="action" value="wicket-acc-orgman-business-docs-upload">
                    <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('wicket-acc-orgman-business-docs-upload'); ?>">
                    <input type="hidden" name="org_id" value="<?php echo esc_attr($org_id); ?>">

                    <div class="documents-upload border p-4 col-12 d-flex flex-column">
                      <h3><?php esc_html_e('Your membership requires at least one of the following documents:', 'wicket-acc'); ?></h3>

                      <ul id="required-docs-list">
                        <?php if (!empty($required_docs)) : ?>
                          <?php foreach ($required_docs as $key => $doc) : ?>
                            <?php
                            $is_optional = is_array($doc) && isset($doc['optional']) && $doc['optional'];
                            $doc_name = is_array($doc) ? $key : $doc;
                            ?>
                            <li>
                              <?php echo esc_html($doc_name); ?>
                              <?php if ($is_optional) : ?>
                                <span class="optional-label"><?php esc_html_e('(if applicable)', 'wicket-acc'); ?></span>
                              <?php endif; ?>
                            </li>
                          <?php endforeach; ?>
                        <?php else : ?>
                          <li><?php esc_html_e('No specific documents required for this business type.', 'wicket-acc'); ?></li>
                        <?php endif; ?>
                      </ul>

                      <div class="documents-upload__dropzone mt-4" id="dropZone" data-loading-disable>
                        <input type="file" class="documents-upload__input" id="fileUpload" name="fileUpload[]" multiple>
                        <div class="documents-upload__prompt">
                          <svg class="documents-upload__icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                          <p class="documents-upload__text">
                            <?php esc_html_e('Drag and drop your files here or', 'wicket-acc'); ?><br /><br />
                            <a href="javascript:void(0);" class="documents-upload__button button button--secondary">
                              <?php esc_html_e('Select Files', 'wicket-acc'); ?>
                            </a>
                          </p>
                        </div>
                        <ul class="documents-upload__file-list" id="fileList"></ul>
                      </div>

                      <p class="text-sm text-center"><?php esc_html_e('Any new set of documents uploaded here, will replace any existing ones.', 'wicket-acc'); ?></p>
                      <p class="text-sm text-center"><?php esc_html_e('Documents file names will be used to present them to your users. Please, keep that in mind, before uploading any files.', 'wicket-acc'); ?></p>

                      <button class="acc-send-documents button button--primary mt-4 align-self-center acc-hidden" id="uploadButton" type="submit"
                        data-loading-class="acc-force-hidden"
                        data-loading-aria-busy
                        data-loading-disable>
                        <?php esc_html_e('Upload Documents', 'wicket-acc'); ?>
                      </button>
                      <div class="acc-spinner transition-all ease-in-out duration-600 align-self-center mt-4"
                        data-loading>
                        <svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <style>
                            .spinner_ajPY {
                              transform-origin: center;
                              animation: spinner_AtaB .75s infinite linear
                            }

                            @keyframes spinner_AtaB {
                              100% {
                                transform: rotate(360deg)
                              }
                            }
                          </style>
                          <path d="M12,1A11,11,0,1,0,23,12,11,11,0,0,0,12,1Zm0,19a8,8,0,1,1,8-8A8,8,0,0,1,12,20Z" opacity=".25" />
                          <path d="M10.14,1.16a11,11,0,0,0-9,8.92A1.59,1.59,0,0,0,2.46,12,1.52,1.52,0,0,0,4.11,10.7a8,8,0,0,1,6.66-6.61A1.42,1.42,0,0,0,12,2.69h0A1.57,1.57,0,0,0,10.14,1.16Z" class="spinner_ajPY" />
                        </svg>
                      </div>

                      <div id="business-docs-form-response"></div>
                    </div>

                  </form>

                  <script>
                    document.addEventListener('DOMContentLoaded', function() {
                      const dropZone = document.getElementById('dropZone');
                      const fileUpload = document.getElementById('fileUpload');
                      const fileList = document.getElementById('fileList');
                      const browseButton = document.querySelector('.documents-upload__button');
                      const uploadButton = document.querySelector('.acc-send-documents'); // Changed to target the unique class

                      // Prevent default drag behaviors
                      ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                        dropZone.addEventListener(eventName, preventDefaults, false);
                        document.body.addEventListener(eventName, preventDefaults, false);
                      });

                      // Highlight drop zone when dragging over it
                      ['dragenter', 'dragover'].forEach(eventName => {
                        dropZone.addEventListener(eventName, highlight, false);
                      });

                      ['dragleave', 'drop'].forEach(eventName => {
                        dropZone.addEventListener(eventName, unhighlight, false);
                      });

                      // Handle dropped files
                      dropZone.addEventListener('drop', handleDrop, false);

                      // Handle selected files
                      fileUpload.addEventListener('change', handleFiles, false);

                      // Handle browse button click
                      browseButton.addEventListener('click', (e) => {
                        e.preventDefault();
                        fileUpload.click();
                      });

                      function preventDefaults(e) {
                        e.preventDefault();
                        e.stopPropagation();
                      }

                      function highlight(e) {
                        dropZone.classList.add('is-dragover');
                      }

                      function unhighlight(e) {
                        dropZone.classList.remove('is-dragover');
                      }

                      function handleDrop(e) {
                        const dt = e.dataTransfer;
                        const files = dt.files;

                        // Create a DataTransfer object
                        const dataTransfer = new DataTransfer();

                        // Add all dropped files to the DataTransfer object
                        Array.from(files).forEach(file => {
                          dataTransfer.items.add(file);
                        });

                        // Set the files to the hidden input
                        fileUpload.files = dataTransfer.files;

                        // Now process the files
                        handleFiles({
                          target: fileUpload
                        });
                      }

                      function handleFiles(e) {
                        const files = [...e.target.files];
                        dropZone.classList.add('has-files');
                        files.forEach(uploadFile);
                        toggleUploadButton();
                      }

                      function uploadFile(file) {
                        const li = document.createElement('li');
                        li.className = 'documents-upload__file-item';

                        const icon = document.createElement('svg');
                        icon.className = 'documents-upload__file-icon';
                        icon.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
            </svg>
        `;

                        const name = document.createElement('span');
                        name.className = 'documents-upload__file-name';
                        name.textContent = file.name;

                        const removeBtn = document.createElement('button');
                        removeBtn.className = 'documents-upload__file-remove';
                        removeBtn.textContent = 'Remove';
                        removeBtn.onclick = () => {
                          li.remove();
                          if (fileList.children.length === 0) {
                            dropZone.classList.remove('has-files');
                          }
                          toggleUploadButton();
                        };

                        li.appendChild(icon);
                        li.appendChild(name);
                        li.appendChild(removeBtn);
                        fileList.appendChild(li);
                      }

                      function toggleUploadButton() {
                        if (fileList.children.length > 0) {
                          uploadButton.classList.remove('acc-hidden');
                        } else {
                          uploadButton.classList.add('acc-hidden');
                        }
                      }
                    });
                  </script>
                </div>
              <?php
              endif;
              ?>

            <?php else : ?>

              <?php
              if ($org_ids) {
                echo "<h2 class='primary_link_color'>" . __('Choose an Organization:', 'wicket-acc') . "</h2>";
                echo "<ul>";
                // lookup org details based on UUID found on the role
                foreach ($org_ids as $org_uuid) {
                  $organization = $client->get("organizations/$org_uuid");
                  echo "<li>";
                  echo "<a class='primary_link_color' href='" . home_url(add_query_arg([], $wp->request)) . "?org_id=$org_uuid'>";
                  echo $organization['data']['attributes']['legal_name_' . $lang];
                  echo "</a>";
                  echo "</li>";
                }
                echo '</ul>';
              } else {
                echo "<p>" . __('You currently have no organizations to manage information for.', 'wicket-acc') . "</p>";
              }
              ?>

            <?php endif; ?>

          </div>
        </div>

        <?php WACC()->renderAccSidebar(); ?>
      </section>
    </main>
<?php endwhile;
endif; ?>

<?php get_footer(); ?>
