<?php

namespace WicketAcc;

// No direct access
defined('ABSPATH') || exit;

/**
 * Template Name: ACC Org-Management Child Orgs Add New
 * Template Post: my-account
 *
 * Locations / Banners / Subsidiaries add new
 */

wicket_orgman_page_role_check(
    [
        'administrator',
        'owner',
        'org_editor',
    ]
);

global $wp, $orgman_pages_slugs, $orgman_pages_url;

$client = WACC()->MdpApi->init_client();
$person = wicket_orgman_get_current_person();
$lang   = defined('ICL_LANGUAGE_CODE') ? ICL_LANGUAGE_CODE : 'en';

$xls_download_url = get_stylesheet_directory_uri() . '/assets/downloads/organization-template-chfa.xlsx';

// Get parent page slug
$current_page     = get_post();
$parent_page_slug = get_post($current_page->post_parent)->post_name;

/**------------------------------------------------------------------
 * Decide whether we are loading an ORG from the URL
 * or looking up all associated orgs to person
 * if there's more than 1, we list them for the user to choose
 * which org they want to see
------------------------------------------------------------------*/
$org_id = $_GET['org_id'] ?? '';

if ($org_id) {
    $org = wicket_get_organization($org_id);
} else {
    $org_ids = [];

    if (is_null($person)) {
        wp_die(__('Person not found. Contact your administrator', 'wicket-acc'));
    }

    // Figure out orgs I should see. This association to the org is set on each role. The actual role types we look at might change depending on the project
    foreach ($person->included() as $person_included) {
        // Warning fix
        if (!isset($person_included['attributes']['name'])) {
            $person_included['attributes']['name'] = '';
        }

        // Assigned roles
        $roles = $person_included['attributes']['assignable_role_names'] ?? [];

        if (
            $person_included['type'] == 'roles' && stristr($person_included['attributes']['name'], 'owner')
            || stristr($person_included['attributes']['name'], 'membership_manager')
            || stristr($person_included['attributes']['name'], 'org_editor')
            || isset(
                $person_included['attributes']['assignable_role_names']
            ) && (
                in_array('membership_manager', $roles)
                || in_array('org_editor', $roles)
            )
        ) {

            if (isset($person_included['relationships']['resource']['data']['id']) && $person_included['relationships']['resource']['data']['type'] == 'organizations') {
                $org_ids[] = $person_included['relationships']['resource']['data']['id'];
            }
        }
    }

    $org_ids = array_unique($org_ids);

    // If they only have 1 org, redirect back to this page with the org ID in the URL to show info for that org. Ese we build a list of their orgs below to choose from
    if (count($org_ids) == 1) {
        $url = strtok($_SERVER["REQUEST_URI"], '?');
        header('Location: ' . $url . '?org_id=' . $org_ids[0]);
        die;
    }
}

get_header();
?>

<?php
$wrapper_classes     = [];
$dev_wrapper_classes = get_field('page_wrapper_class');
if (!empty($dev_wrapper_classes)) {
    $wrapper_classes[] = $dev_wrapper_classes;
}

// Class for Roster Managment styling
$wrapper_classes[] = 'wicket-acc';
$wrapper_classes[] = 'roster-management';
$wrapper_classes[] = 'wicket-acc-container';
$wrapper_classes[] = 'acc-organization-management';
$wrapper_classes[] = 'wicket-acc-orgman-childorgs';

$display_breadcrumb   = get_field('display_breadcrumb');
$display_publish_date = get_field('display_publish_date');
?>

<?php
WACC()->renderGlobalSubHeader();
?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

        <?php
        if ($display_breadcrumb) {
            echo '<div class="wp-block-breadcrumbs">'; // Having the `wp-block-` prefix will help align it with the other Blocks
            get_component('breadcrumbs', []);
            echo '</div>';
        }
        if ($display_publish_date) {
            echo '<div class="wp-block-published-date">';
            echo "<p class='mt-3 mb-4'><strong>" . __('Published:', 'wicket-acc') . ' ' . get_the_date('d-m-Y') . "</strong></p>";
            echo '</div>';
        }
        ?>

        <main
            class="<?php echo implode(' ', $wrapper_classes) ?> container mb-8"
            id="main-content">

            <section id="content" class="woocommerce-wicket--container section page-default">
                <div class="wicket-acc-page woocommerce-wicket--account-centre row">
                    <?php the_content(); ?>

                    <?php
                    if ($org_id) :
                        $org_info = wicket_orgman_get_organization_info_extended($org_id, $lang);

                        if (!$org_info) {
                            wp_die(__('Organization info not found', 'wicket-acc'));
                        }
                    ?>

                        <?php
                        if (component_exists('org-search-select')) {
                            // organization-create-subsidiary
                            $create_subsidiary_url = add_query_arg(
                                'org_id',
                                $org_id,
                                home_url('/my-account') . '/organization-create-subsidiary/'
                            );

                            get_component('org-search-select', [
                                'classes'               => ['wicket-acc-childorgs-search-select'],
                                'search_mode'           => 'org',
                                'title'                 => __('What is the name of the location / banner / subsidiary you want to add?', 'wicket-acc'),
                                'disable_create_org_ui' => true,
                                'relationship_mode'     => 'organization_parent',
                                'response_message'      => 'wicket-acc-childorgs__response-message',
                                'no_results_found_message' => '<div class="flex flex-col"><p class="mb-4 text-center">' . esc_html__('No matches found.', 'wicket-acc') . '</p><p><a href="' . esc_url($create_subsidiary_url) . '" class="button button--primary">' . __('Create New Location / Banner / Subsidiary', 'wicket-acc') . '</a></p></div>',
                            ], true);
                        } else {
                            echo '<p>' . esc_html__('Org search/select component is missing. Please update Wicket Base Plugin.', 'wicket-acc') . '</p>';
                        }
                        ?>

                        <div class="wicket-acc-childorgs__response-message d-flex" x-data="orgssResponseMessage">
                            <div class="response-message alert alert-success flex-column w-100" x-show="open" x-transition>
                                <button class="align-self-end" @click="open = false; clearTimeout(timer)"><?php echo esc_html__('Close', 'wicket-acc'); ?></button>
                                <p x-text="message" class="align-self-center px-4 pb-4"></p>
                            </div>
                        </div>
                        <script>
                            document.addEventListener('alpine:init', () => {
                                Alpine.data('orgssResponseMessage', () => ({
                                    open: false,
                                    message: '',
                                    timer: null,
                                    init() {
                                        window.addEventListener('new-org-connected', (event) => {
                                            this.message = event.detail.message;
                                            this.open = true;

                                            // Clear any existing timer
                                            if (this.timer) clearTimeout(this.timer);

                                            // Set a new timer to close after 5 seconds
                                            this.timer = setTimeout(() => {
                                                this.open = false;
                                                this.message = '';
                                            }, 7000);
                                        });
                                    }
                                }));
                            });
                        </script>

                        <div class=" container my-4">
                            <!-- Section Header -->
                            <div class="card border rounded p-4 upload-section">
                                <h2 class="fw-bold"><?php echo esc_html__('Ask CHFA to Add Locations / Banners / Subsidiaries For You', 'wicket-acc'); ?></h2>
                                <p><?php echo esc_html__('If you have more than 3, you can download the attached spreadsheet to add additional store information, and upload it here.', 'wicket-acc'); ?></p>

                                <!-- Step Instructions -->
                                <p class="fw-bold mt-4"><?php echo esc_html__('STEP 1: Download spreadsheet', 'wicket-acc'); ?></p>

                                <p class="d-flex">
                                    <a href="<?php echo esc_url($xls_download_url); ?>" class="button button--primary btn btn-download mb-3" aria-label="<?php echo esc_attr__('Download Spreadsheet', 'wicket-acc'); ?>">
                                        <i class="bi bi-download me-2"></i> <?php echo esc_html__('Download Spreadsheet', 'wicket-acc'); ?>
                                    </a>
                                </p>

                                <p class="fw-bold"><?php echo esc_html__('STEP 2: Fill in all information on the spreadsheet.', 'wicket-acc'); ?></p>

                                <p class="fw-bold"><?php echo esc_html__('STEP 3: Upload the spreadsheet below once you’ve filled it in.', 'wicket-acc'); ?></p>

                                <form id="wicket-acc-orgman-childorgs-xls" name="wicket-acc-orgman-childorgs-xls"
                                    method="post"
                                    enctype="multipart/form-data"
                                    hx-encoding="multipart/form-data"
                                    hx-post="<?php echo wicket_orgman_htmx_url(); ?>?to=account-centre/org-management/subsidiaries-xls-upload"
                                    hx-swap="innerHTML transition:true"
                                    hx-target="#wicket-acc-orgman-childorgs-xls"
                                    hx-disabled-elt="this"
                                    class="slide-it">

                                    <div class=" d-flex flex-column flex-md-row align-items-center gap-2">
                                        <input id="placeholder" name="placeholder" type="text" class="form-control file-input mb-2 mb-md-0" placeholder="No file chosen" aria-label="Chosen File Name" readonly>

                                        <input id="fileUpload" name="fileUpload" type="file" class="d-none" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet">

                                        <label for="fileUpload" class="button button--primary button--choose-file" aria-label="<?php esc_attr_e('Choose File', 'wicket-acc'); ?>"><?php echo esc_html__('Choose File', 'wicket-acc'); ?></label>

                                        <button type="submit" id="uploadFile" class="button button--secondary button--upload" aria-label="<?php esc_attr_e('Upload', 'wicket-acc'); ?>" disabled><?php echo esc_html__('Upload', 'wicket-acc'); ?></button>

                                        <?php wp_nonce_field('wicket-acc-orgman-childorgs-xls', 'nonce'); ?>
                                        <input type="hidden" id="userId" name="userId" value="<?php echo get_current_user_id(); ?>">
                                        <input type="hidden" id="action" name="action" value="wicket-acc-orgman-childorgs-xls">
                                    </div>

                                </form>

                                <script>
                                    document.addEventListener('DOMContentLoaded', function() {
                                        let fileInput = document.getElementById('fileUpload');
                                        let filePlaceholder = document.getElementById('placeholder');

                                        fileInput.addEventListener('change', function() {
                                            if (fileInput.files.length > 0) {
                                                filePlaceholder.value = fileInput.files[0].name;
                                            } else {
                                                filePlaceholder.value = '<?php esc_html_e('No file chosen', 'wicket-acc'); ?>';
                                            }
                                        });

                                        // On file selection, enable the upload button
                                        fileInput.addEventListener('change', function() {
                                            document.getElementById('uploadFile').disabled = false;
                                        });

                                        // On submit, disable the upload button
                                        document.getElementById('wicket-acc-orgman-childorgs-xls').addEventListener('submit', function() {
                                            document.getElementById('uploadFile').disabled = true;
                                        })
                                    });
                                </script>

                                <div id="wicket-acc-orgman-form-response"></div>
                            </div>
                        </div>

                    <?php
                    else :
                    ?>
                        <p><?php echo esc_html__('You currently have no organizations to manage members for.', 'wicket-acc'); ?>
                        </p>
                    <?php
                    endif;
                    ?>
                </div>

                <?php WACC()->renderAccSidebar(); ?>
            </section>
        </main>
<?php endwhile;
endif; ?>

<?php get_footer(); ?>
