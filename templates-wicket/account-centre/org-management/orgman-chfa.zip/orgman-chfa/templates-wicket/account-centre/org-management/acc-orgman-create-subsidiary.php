<?php

namespace WicketAcc;

// No direct access
defined('ABSPATH') || exit;

/**
 * Template Name: ACC Org-Management Index
 * Template Post: my-account
 */

wicket_orgman_page_role_check(
  [
    'administrator',
    'owner',
    'childorg_editor',
  ]
);

global $wp, $orgman_pages_slugs, $orgman_pages_url;

$client   = WACC()->MdpApi->init_client();
$person   = wicket_orgman_get_current_person();
$userUuid = $person->id;
$lang     = defined('ICL_LANGUAGE_CODE') ? ICL_LANGUAGE_CODE : 'en';

$org_types_wicket = wicket_get_org_types_list();
$org_types = [];
$allowed_org_types = [
  'brand',
  'subsidiary',
  'location_banner'
];

foreach ($org_types_wicket as $type) {
  if (empty($allowed_org_types) || in_array($type['attributes']['slug'], $allowed_org_types)) {
    $org_types[] = [
      'name'  => ICL_LANGUAGE_CODE == 'en' ? $type['attributes']['name_en'] : $type['attributes']['name_fr'],
      'value' => $type['attributes']['slug'] ?? '',
    ];
  }
}

// Get parent page slug
$current_page     = get_post();
$parent_page_slug = get_post($current_page->post_parent)->post_name;

/**------------------------------------------------------------------
 * Decide whether we are loading an ORG from the URL
 * or looking up all associated orgs to person
 * if there's more than 1, we list them for the user to choose
 * which org they want to see
------------------------------------------------------------------*/
$org_id = $_GET['org_id'] ?? '';

if ($org_id) {
  $org = wicket_get_organization($org_id);
} else {
  $org_ids = [];

  if (is_null($person)) {
    wp_die(__('Person not found. Contact your administrator', 'wicket-acc'));
  }

  // Figure out orgs I should see. This association to the org is set on each role. The actual role types we look at might change depending on the project
  foreach ($person->included() as $person_included) {
    // Warning fix
    if (!isset($person_included['attributes']['name'])) {
      $person_included['attributes']['name'] = '';
    }

    // Assigned roles
    $roles = $person_included['attributes']['assignable_role_names'] ?? [];

    if (
      $person_included['type'] == 'roles' && stristr($person_included['attributes']['name'], 'owner')
      || stristr($person_included['attributes']['name'], 'membership_manager')
      || stristr($person_included['attributes']['name'], 'org_editor')
      || isset(
        $person_included['attributes']['assignable_role_names']
      ) && (
        in_array('membership_manager', $roles)
        || in_array('org_editor', $roles)
      )
    ) {

      if (isset($person_included['relationships']['resource']['data']['id']) && $person_included['relationships']['resource']['data']['type'] == 'organizations') {
        $org_ids[] = $person_included['relationships']['resource']['data']['id'];
      }
    }
  }

  $org_ids = array_unique($org_ids);

  // If they only have 1 org, redirect back to this page with the org ID in the URL to show info for that org. Ese we build a list of their orgs below to choose from
  if (count($org_ids) == 1) {
    $url = strtok($_SERVER["REQUEST_URI"], '?');
    header('Location: ' . $url . '?org_id=' . $org_ids[0]);
    die;
  }

  // Here, we also need to always redirect to the parent org, and ignore child orgs. Parent one should be the first one
  if (count($org_ids) > 1) {
    $url = strtok($_SERVER["REQUEST_URI"], '?');
    header('Location: ' . $url . '?org_id=' . $org_ids[0]);
    die;
  }
}

get_header();
?>

<?php
$wrapper_classes     = [];
$dev_wrapper_classes = get_field('page_wrapper_class');
if (!empty($dev_wrapper_classes)) {
  $wrapper_classes[] = $dev_wrapper_classes;
}

// Class for Roster Managment styling
$wrapper_classes[] = 'wicket-acc';
$wrapper_classes[] = 'roster-management';
$wrapper_classes[] = 'acc-organization-management';
$wrapper_classes[] = 'wicket-acc-container';

$display_breadcrumb   = get_field('display_breadcrumb');
$display_publish_date = get_field('display_publish_date');
?>

<?php
WACC()->renderGlobalSubHeader();
?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

    <?php
    if ($display_breadcrumb) {
      echo '<div class="wp-block-breadcrumbs">'; // Having the `wp-block-` prefix will help align it with the other Blocks
      get_component('breadcrumbs', []);
      echo '</div>';
    }
    if ($display_publish_date) {
      echo '<div class="wp-block-published-date">';
      echo "<p class='mt-3 mb-4'><strong>" . __('Published:', 'wicket-acc') . ' ' . get_the_date('d-m-Y') . "</strong></p>";
      echo '</div>';
    }
    ?>

    <main
      class="<?php echo implode(' ', $wrapper_classes) ?> container mb-8"
      id="main-content">

      <section id="content" class="woocommerce-wicket--container section page-default">

        <div class="wicket-acc-page woocommerce-wicket--account-centre row">
          <div class="columns large-8">

            <?php the_content(); ?>

            <?php
            if ($org_id) :
              $org_info = wicket_orgman_get_organization_info_extended($org_id, $lang);

              if (!$org_info) {
                wp_die(__('Organization info not found', 'wicket-acc'));
              }
            ?>
              <div class="wicket-welcome-block bg-light-010 rounded-100 p-4 mb-4">
                <h2 class='organization_name heading-lg font-weight:400 dark-100'>
                  <?php echo $org_info['org_name'] ?>
                </h2>

                <?php if (!empty($org_info['org_meta']['main_address'])) : ?>
                  <p class='formatted_address_label mb-4'>
                    <?php echo $org_info['org_meta']['main_address']['formatted_address_label']; ?>
                  </p>

                  <?php if (isset($org_info['org_meta']['main_email']['address'])) : ?>
                    <p class="email_address mb-4">
                    <h5 class="font-bold">
                      <?php _e('Email Address', 'wicket-acc') ?>
                    </h5>
                    <?php echo $org_info['org_meta']['main_email']['address'] ?>
                    </p>
                  <?php endif; ?>

                  <?php if (isset($org_info['org_meta']['main_phone']['number_international_format'])) : ?>
                    <p class="phone_number mb-4">
                    <h5 class="font-bold">
                      <?php _e('Phone Number', 'wicket-acc') ?>
                    </h5>
                    <?php echo $org_info['org_meta']['main_phone']['number_international_format']; ?>
                    </p>
                  <?php endif; ?>
                <?php endif; ?>
              </div>

              <div class="wicket-orgman-profile-component">
                <form class="profile__form" id="wicket-acc-orgman-create-childorg" name="childorg_form" method="post" enctype="multipart/form-data"
                  hx-encoding="multipart/form-data"
                  hx-post="<?php echo wicket_orgman_htmx_url(); ?>?to=account-centre/org-management/create-subsidiary"
                  hx-swap="innerHTML transition:true"
                  hx-target="#htmxResponse"
                  hx-on::after-request="this.reset()"
                  hx-disabled-elt="this"
                  hx-ext="loading-states"
                  class="slide-it">
                  <div class="container mb-5" data-loading-disable>
                    <div class="row justify-content-center">
                      <div class="col-12">
                        <main class="profile">
                          <h1 class="profile__title"><?php esc_attr_e('Create a new Subsidiary', 'wicket-acc'); ?></h1>

                          <div class="profile__form-group">
                            <label class="profile__label" for="name"><?php esc_html_e('Name', 'wicket-acc'); ?><span class="field_required">*</span></label>
                            <input class="profile__input" type="text" id="name" name="name" value="" required>
                          </div>

                          <div class="profile__form-group">
                            <label class="profile__label" for="type"><?php esc_html_e('Type', 'wicket-acc'); ?><span class="field_required">*</span></label>
                            <?php
                            if ($org_types) {
                            ?>
                              <select class="profile__input" id="type" name="type" required>
                                <?php foreach ($org_types as $orgt) : ?>
                                  <option value="<?php echo $orgt['value']; ?>"><?php echo $orgt['name']; ?></option>
                                <?php endforeach; ?>
                              </select>
                            <?php
                            }
                            ?>
                          </div>

                          <div class="profile__form-group">
                            <label class="profile__label" for="description"><?php esc_html_e('Description', 'wicket-acc'); ?><span class="field_required">*</span></label>
                            <textarea class="profile__input" id="description" name="description" rows="3" required></textarea>
                          </div>

                          <div class="profile__form-group profile__form-group-address container">
                            <label class="profile__label" for="address"><?php esc_html_e('Address', 'wicket-acc'); ?><span class="field_required">*</span></label>
                            <div class="row address-wrapper my-3 p-3">
                              <div class="col-12 mb-3">
                                <label class="subsidiary__label" for="company">
                                  <?php esc_html_e('Company / Building name', 'wicket-acc'); ?>
                                </label>
                                <input class="subsidiary__input" type="text" id="company" name="company" value="">
                              </div>

                              <div class="col-12 col-md-6 mb-3">
                                <label class="subsidiary__label" for="department">
                                  <?php esc_html_e('Department Name', 'wicket-acc'); ?>
                                </label>
                                <input class="subsidiary__input" type="text" id="department" name="department" value="">
                              </div>

                              <div class="col-12 col-md-6 mb-3">
                                <label class="subsidiary__label" for="division">
                                  <?php esc_html_e('Division Name', 'wicket-acc'); ?>
                                </label>
                                <input class="subsidiary__input" type="text" id="division" name="division" value="">
                              </div>

                              <div class="col-12 col-md-6 mb-3">
                                <label class="subsidiary__label" for="street">
                                  <?php esc_html_e('Street Address', 'wicket-acc'); ?>
                                  <span class="field_required">*</span>
                                </label>
                                <input class="subsidiary__input" type="text" id="street" name="street" value="" required>
                              </div>

                              <div class="col-12 col-md-6 mb-3">
                                <label class="subsidiary__label" for="suite">
                                  <?php esc_html_e('Apt / Suite', 'wicket-acc'); ?>
                                </label>
                                <input class="subsidiary__input" type="text" id="suite" name="suite" value="">
                              </div>

                              <div class="col-12 mb-3">
                                <label class="subsidiary__label" for="city">
                                  <?php esc_html_e('City / Town', 'wicket-acc'); ?>
                                  <span class="field_required">*</span>
                                </label>
                                <input class="subsidiary__input" type="text" id="city" name="city" value="" required>
                              </div>
                              <?php
                              $countries       = wicket_orgman_getCountries();
                              $statesProvinces = wicket_orgman_getStatesProvinces();
                              $statesByCountry = [];

                              if (!empty($countries) && !empty($statesProvinces)) {
                                // Prepare states/provinces data
                                foreach ($statesProvinces as $state) {
                                  $countryCode = $state[0];
                                  if (!isset($statesByCountry[$countryCode])) {
                                    $statesByCountry[$countryCode] = [];
                                  }
                                  $statesByCountry[$countryCode][] = [
                                    'code' => $state[1],
                                    'name' => $state[2]
                                  ];
                                }
                              } else {
                                esc_html_e('There was an error loading countries and provinces data. Please try again later.', 'wicket');
                              }
                              ?>
                              <div class="col-12 col-md-4 mb-3">
                                <label class="subsidiary__label" for="country">
                                  <?php esc_html_e('Country', 'wicket'); ?>
                                  <span class="field_required">*</span>
                                </label>
                                <select class="subsidiary__input subsidiary__select" id="country" name="country" required>
                                  <option value=""></option>
                                  <?php foreach ($countries as $country): ?>
                                    <option value="<?php echo htmlspecialchars($country[0]) ?>"><?php echo htmlspecialchars($country[1]) ?></option>
                                  <?php endforeach; ?>
                                </select>
                              </div>

                              <div class="col-12 col-md-4 mb-3">
                                <label class="subsidiary__label" for="province">
                                  <?php esc_html_e('Province / State', 'wicket-acc'); ?>
                                  <span class="field_required">*</span>
                                </label>
                                <select class="subsidiary__input subsidiary__select" id="province-select" name="province" style="display: none;">
                                  <option value=""></option>
                                </select>
                                <input type="text" id="province-input" name="province">
                              </div>

                              <div class="col-12 col-md-4 mb-3">
                                <label class="subsidiary__label" for="postal">
                                  <?php esc_html_e('Postal / Zip code', 'wicket-acc'); ?>
                                  <span class="field_required">*</span>
                                </label>
                                <input class="subsidiary__input" type="text" id="postal" name="postal" value="" required>
                              </div>
                            </div>
                          </div>

                          <div class="profile__form-group">
                            <label class="profile__label" for="email"><?php esc_html_e('Primary Email', 'wicket-acc'); ?><span class="field_required">*</span></label>
                            <input class="profile__input" type="email" id="email" name="email" value="" required>
                          </div>

                          <div class="profile__form-group">
                            <label class="profile__label" for="phone"><?php esc_html_e('Phone', 'wicket-acc'); ?><span class="field_required">*</span></label>
                            <input class="profile__input wicket-phone-autoformat" type="tel" id="phone" name="phone" value="" required>
                          </div>

                          <div class="profile__form-group">
                            <label class="profile__label" for="website"><?php esc_html_e('Web Address', 'wicket-acc'); ?><span class="field_required">*</span></label>
                            <input class="profile__input" type="url" id="website" name="website" placeholder="<?php esc_attr_e('https://', 'wicket-acc'); ?>" value="" required>
                          </div>

                          <?php wp_nonce_field('wicket-acc-orgman-create-childorg', 'nonce'); ?>
                          <input type="hidden" name="parent_org" value="<?php echo $org_id; ?>">
                          <input type="hidden" id="userUuid" name="userUuid" value="<?php echo $userUuid; ?>">
                          <input type="hidden" id="userId" name="userId" value="<?php echo get_current_user_id(); ?>">
                          <input type="hidden" id="action" name="action" value="wicket-acc-orgman-create-childorg">
                        </main>
                      </div>
                    </div>
                  </div>

                  <div class="wicket-orgman-create-subsidiary-add">
                    <button id="submit-button" class="button button--primary submit__button transition-all ease-in-out duration-600" type="submit"
                      data-loading-class="acc-force-hidden"
                      data-loading-aria-busy
                      data-loading-disable>
                      <?php esc_html_e('Create Organization', 'wicket-acc'); ?>
                    </button>
                    <div class="acc-spinner transition-all ease-in-out duration-600"
                      data-loading>
                      <svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <style>
                          .spinner_ajPY {
                            transform-origin: center;
                            animation: spinner_AtaB .75s infinite linear
                          }

                          @keyframes spinner_AtaB {
                            100% {
                              transform: rotate(360deg)
                            }
                          }
                        </style>
                        <path d="M12,1A11,11,0,1,0,23,12,11,11,0,0,0,12,1Zm0,19a8,8,0,1,1,8-8A8,8,0,0,1,12,20Z" opacity=".25" />
                        <path d="M10.14,1.16a11,11,0,0,0-9,8.92A1.59,1.59,0,0,0,2.46,12,1.52,1.52,0,0,0,4.11,10.7a8,8,0,0,1,6.66-6.61A1.42,1.42,0,0,0,12,2.69h0A1.57,1.57,0,0,0,10.14,1.16Z" class="spinner_ajPY" />
                      </svg>
                    </div>
                  </div>

                  <div id="htmxResponse" class="my-4"></div>
                </form>
              </div>
            <?php else: ?>

              <?php
              if ($org_ids) {
                echo "<h2 class='primary_link_color'>" . __('Choose an Organization:', 'wicket-acc') . "</h2>";
                echo "<ul>";
                // lookup org details based on UUID found on the role
                foreach ($org_ids as $org_uuid) {
                  $organization = $client->get("organizations/$org_uuid");
                  echo "<li>";
                  echo "<a class='primary_link_color' href='" . home_url(add_query_arg([], $wp->request)) . "/?org_id=$org_uuid'>";
                  echo $organization['data']['attributes']['legal_name_' . $lang];
                  echo "</a>";
                  echo "</li>";
                }
                echo '</ul>';
              } else {
              ?>
                <p><?php echo esc_html__('You currently have no organizations to manage members for.', 'wicket-acc'); ?>
                </p>
              <?php
              }
              ?>

            <?php
            endif;
            ?>
          </div>
        </div>

        <?php WACC()->renderAccSidebar(); ?>
      </section>
    </main>
<?php endwhile;
endif; ?>

<script>
  // Clear htmx response
  document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('htmxResponse').innerHTML = '';
  });

  // Store states/provinces data
  const statesByCountry = <?php echo json_encode($statesByCountry) ?>;

  // Get DOM elements
  const countrySelect = document.getElementById('country');
  const provinceSelect = document.getElementById('province-select');
  const provinceInput = document.getElementById('province-input');

  // Function to update province/state field
  function wicketUpdateProvinceField() {
    const selectedCountry = countrySelect.value;
    const hasStates = ['US', 'CA'].includes(selectedCountry);

    if (hasStates) {
      // Show select, hide input
      provinceSelect.style.display = 'block';
      provinceInput.style.display = 'none';
      // Enable select, disable input
      provinceSelect.required = true;
      provinceSelect.disabled = false;
      provinceInput.required = false;
      provinceInput.disabled = true;
    } else {
      // Show input, hide select
      provinceSelect.style.display = 'none';
      provinceInput.style.display = 'block';
      // Enable input, disable select
      provinceSelect.required = false;
      provinceSelect.disabled = true;
      provinceInput.required = true;
      provinceInput.disabled = false;
    }

    // Clear values
    provinceSelect.value = '';
    provinceInput.value = '';

    // If country has predefined states, populate the select
    if (hasStates) {
      // Clear existing options except the first one
      while (provinceSelect.options.length > 1) {
        provinceSelect.remove(1);
      }

      // Add new options
      const states = statesByCountry[selectedCountry] || [];
      states.forEach(state => {
        const option = new Option(state.name, state.code);
        provinceSelect.add(option);
      });
    }
  }

  // Add event listener for country change
  countrySelect.addEventListener('change', wicketUpdateProvinceField);

  // Initialize the province field
  wicketUpdateProvinceField();
</script>

<?php get_footer(); ?>
