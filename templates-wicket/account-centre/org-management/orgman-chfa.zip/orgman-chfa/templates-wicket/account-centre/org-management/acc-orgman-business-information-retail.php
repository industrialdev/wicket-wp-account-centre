<?php

namespace WicketAcc;

// No direct access
defined('ABSPATH') || exit;

/**
 * Template Name: ACC Org-Management Business Information (Retail)
 * Template Post: my-account
 */

wicket_orgman_page_role_check(
  [
    'administrator',
    'owner',
    'org_editor',
  ]
);

global $wp, $orgman_pages_slugs, $orgman_pages_url;

$org_id       = isset($_REQUEST['org_id']) ? $_REQUEST['org_id'] : '';
$child_org_id = isset($_REQUEST['child_org_id']) ? $_REQUEST['child_org_id'] : '';

wicket_orgman_business_edit_redirect($org_id);

$client = WACC()->MdpApi->init_client();
$person = wicket_orgman_get_current_person();
$lang   = defined('ICL_LANGUAGE_CODE') ? ICL_LANGUAGE_CODE : 'en';

$environment = get_option('wicket_admin_settings_environment');

if (!$environment) {
  $environment[0] = 'dev';
}

$full_time_employees_schema = $environment[0] == 'prod' ? 'e981bd15-8ce1-402f-b3a8-8ebec40ce66d' : '3f986a58-0a25-4e7a-83aa-0ad8736da541';
$organization_stats_schema = $environment[0] == 'prod' ? '8870bae7-6ac6-4993-9031-fb90d4d772a5' : '79a7a472-a843-4605-ae6e-b5eb440cfde5';
$location_data_schema = $environment[0] == 'prod' ? '1766eaa6-e3d5-408c-a7cd-e221c496069b' : '746dee68-91ad-419d-9e67-6be64c63a98e';
$business_type_schema = $environment[0] == 'prod' ? '3bc5ec95-63f7-4e0f-89d3-2dc8acf2c241' : '29d74c5e-4620-409c-a521-b30a03c365ef';

/**------------------------------------------------------------------
 * Decide whether we are loading an ORG from the URL
 * or looking up all associated orgs to person
 * if there's more than 1, we list them for the user to choose
 * which org they want to see
------------------------------------------------------------------*/
// Override org_id if child_org_id is set
$parent_org_id = $org_id;
$org_id = isset($_REQUEST['child_org_id']) ? $_REQUEST['child_org_id'] : $org_id;

if ($org_id) {
  $org = wicket_get_organization($org_id);
} else {
  $org_ids = [];

  // Figure out orgs I should see. This association to the org is set on each role. The actual role types we look at might change depending on the project
  foreach ($person->included() as $person_included) {
    // Warning fix
    if (!isset($person_included['attributes']['name'])) {
      $person_included['attributes']['name'] = '';
    }

    // Assigned roles
    $roles = $person_included['attributes']['assignable_role_names'] ?? [];

    if (
      $person_included['type'] == 'roles' && stristr($person_included['attributes']['name'], 'owner')
      || stristr($person_included['attributes']['name'], 'membership_manager')
      || stristr($person_included['attributes']['name'], 'org_editor')
      || isset(
        $person_included['attributes']['assignable_role_names']
      ) && (
        in_array('membership_manager', $roles)
        || in_array('org_editor', $roles)
      )
    ) {

      if (isset($person_included['relationships']['resource']['data']['id']) && $person_included['relationships']['resource']['data']['type'] == 'organizations') {
        $org_ids[] = $person_included['relationships']['resource']['data']['id'];
      }
    }
  }

  $org_ids = array_unique($org_ids);

  // If they only have 1 org, redirect back to this page with the org ID in the URL to show info for that org. Ese we build a list of their orgs below to choose from
  if (count($org_ids) == 1) {
    $url = strtok($_SERVER["REQUEST_URI"], '?');
    if (!headers_sent()) {
      header('Location: ' . $url . '?org_id=' . $org_ids[0]);
    } else {
      echo '<meta http-equiv="refresh" content="0; url=' . $url . '?org_id=' . $org_ids[0] . '" />';
    }
    die;
  }
}

get_header();
$wicket_user_id = wicket_current_person_uuid();
?>

<?php
$wrapper_classes     = [];
$dev_wrapper_classes = get_field('page_wrapper_class');
if (!empty($dev_wrapper_classes)) {
  $wrapper_classes[] = $dev_wrapper_classes;
}

// Class for Roster Managment styling
$wrapper_classes[] = 'wicket-acc';
$wrapper_classes[] = 'roster-management';
$wrapper_classes[] = 'acc-organization-management';
$wrapper_classes[] = 'wicket-acc-container';

$display_breadcrumb   = get_field('display_breadcrumb');
$display_publish_date = get_field('display_publish_date');
?>

<?php
WACC()->renderGlobalSubHeader();
?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

    <?php
    if ($display_breadcrumb) {
      echo '<div class="wp-block-breadcrumbs">'; // Having the `wp-block-` prefix will help align it with the other Blocks
      get_component('breadcrumbs', []);
      echo '</div>';
    }
    if ($display_publish_date) {
      echo '<div class="wp-block-published-date">';
      echo "<p class='mt-3 mb-4'><strong>" . __('Published:', 'wicket-acc') . ' ' . get_the_date('d-m-Y') . "</strong></p>";
      echo '</div>';
    }
    ?>

    <main
      class="<?php echo implode(' ', $wrapper_classes) ?> container mb-8"
      id="main-content">

      <section id="content" class="woocommerce-wicket--container section page-default">

        <div class="wicket-acc-page woocommerce-wicket--account-centre row mb-4">
          <div class="columns large-8 wicket-acc-orgman wicket-acc-orgman-business-info container">

            <?php the_content(); ?>

            <?php if ($org_id) : ?>

              <?php
              wicket_orgman_business_info_header($org_id, $lang);
              ?>

              <?php
              $business_type_sub = isset($org['data']['attributes']['data_fields'][0]['value']['orgtypesubcat'])
                ? $org['data']['attributes']['data_fields'][0]['value']['orgtypesubcat']
                : '';
              $supplier_subcat = isset($org['data']['attributes']['data_fields'][0]['value']['suppliersubcategory'])
                ? $org['data']['attributes']['data_fields'][0]['value']['suppliersubcategory']
                : '';

              // Find practitioner type in data fields
              $practitioner_type = null;
              $practitioner_field = null;
              $practitioner_schema = 'urn:uuid:39ee0b10-eba5-4e48-be81-eb31ba639d2f';
              foreach ($org['data']['attributes']['data_fields'] as $field) {
                if (isset($field['$schema']) && $field['$schema'] === $practitioner_schema) {
                  $practitioner_type = $field['value']['practype'] ?? null;
                  $practitioner_field = $field; // Store the whole field for "other" case
                  break;
                }
              }
              ?>
              <?php if (!empty($business_type_sub) || !empty($supplier_subcat) || !empty($practitioner_type)): ?>
                <div class="no-categories mb-4">
                  <ul>
                    <?php if (!empty($business_type_sub)): ?>
                      <li>
                        <h4 class="font-bold text-xl">
                          <?php
                          esc_html_e('Business Type:', 'wicket-acc');
                          echo '</h4>';

                          $display_name = wicket_orgman_get_schema_display_name(
                            $org['included'],
                            'orgclasssubcat',
                            'orgtypesubcat',
                            $business_type_sub,
                            $lang
                          );

                          if ($display_name) {
                            echo esc_html($display_name);
                          }
                          ?>
                      </li>
                    <?php endif; ?>
                    <?php if (!empty($supplier_subcat)): ?>
                      <li>
                        <h4 class="font-bold text-xl">
                          <?php
                          esc_html_e('Supplier Subcategory:', 'wicket-acc');
                          echo '</h4>';

                          $display_name = wicket_orgman_get_schema_display_name(
                            $org['included'],
                            'orgclasssubcat',
                            'suppliersubcategory',
                            $supplier_subcat,
                            $lang
                          );

                          if ($display_name) {
                            echo esc_html($display_name);
                          }
                          ?>
                      </li>
                    <?php endif; ?>
                    <?php if (!empty($practitioner_type)): ?>
                      <li>
                        <h4 class="font-bold text-xl">
                          <?php
                          esc_html_e('Practitioner Type:', 'wicket-acc');
                          echo '</h4>';

                          $display_name = wicket_orgman_get_schema_display_name(
                            $org['included'],
                            $practitioner_schema,
                            'practype',
                            $practitioner_type,
                            $lang,
                            $practitioner_field // Pass the whole field
                          );

                          if ($display_name) {
                            echo esc_html($display_name);
                          }
                          ?>
                      </li>
                    <?php endif; ?>
                  </ul>
                </div>
              <?php endif; ?>

              <form class="business-form"
                id="business-info-form"
                name="business-info-form"
                hx-post="<?php echo wicket_orgman_htmx_url(); ?>?to=account-centre/org-management/business-information"
                hx-swap="innerHTML transition:true"
                hx-target="#business-form-response"
                hx-disabled-elt="this"
                hx-ext="loading-states">
                <input type="hidden" name="action" value="wicket-acc-orgman-business-info">
                <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('wicket-acc-orgman-business-info'); ?>">
                <input type="hidden" name="org_id" value="<?php echo esc_attr($org_id); ?>">

                <div class="no-categories mb-4">
                  <?php
                  // Operational Status Section
                  $operational_status = wicket_orgman_get_org_additional_info($org_id, 'Operational Status', $lang);

                  if ($operational_status && isset($operational_status['fields'])) {
                    wicket_orgman_render_additional_info_section('operational-status', $operational_status);
                  }
                  ?>

                  <?php
                  // Legal Name Section
                  $legal_name = wicket_orgman_get_org_additional_info($org_id, 'Legal Name', $lang);

                  if ($legal_name && isset($legal_name['fields'])) {
                    wicket_orgman_render_additional_info_section('legal-name', $legal_name);
                  }
                  ?>

                  <?php
                  // Number of Employees Section
                  $number_of_employees = wicket_orgman_get_org_additional_info($org_id, 'orgnumemp', $lang);

                  if ($number_of_employees && isset($number_of_employees['fields'])) {
                    wicket_orgman_render_additional_info_section('number-of-employees', $number_of_employees);
                  }
                  ?>
                </div> <!-- / .no-categories -->

                <div class="no-categories mb-4">
                  <?php
                  // Retail Presence Section
                  $retail_presence = wicket_orgman_get_org_additional_info($org_id, 'Retail Presence', $lang);

                  if ($retail_presence && isset($retail_presence['fields'])) {
                    wicket_orgman_render_additional_info_section('retail-presence', $retail_presence);
                  }
                  ?>
                </div> <!-- / .no-categories -->

                <div class="no-categories mb-4">
                  <?php
                  // Revenue Section
                  $revenue = wicket_orgman_get_org_additional_info($org_id, 'Revenue', $lang);

                  if ($revenue && isset($revenue['fields'])) {
                    wicket_orgman_render_additional_info_section('revenue', $revenue);
                  }
                  ?>
                </div> <!-- / .no-categories -->

                <div class="business-categories mb-4">
                  <?php
                  // Business Categories Section
                  $categories_section = [
                    'title' => __('Business Categories', 'wicket-acc'),
                    'description' => __('In the sections below, select all that apply to your business.', 'wicket-acc')
                  ];

                  // Get all category sections
                  $company_attributes = wicket_orgman_get_org_additional_info($org_id, 'Company Attributes', $lang);
                  $certifications = wicket_orgman_get_org_additional_info($org_id, 'Certifications', $lang);
                  $business_services = wicket_orgman_get_org_additional_info($org_id, 'Business Services', $lang);
                  $interests = wicket_orgman_get_org_additional_info($org_id, 'Interests', $lang);
                  $product_segments = wicket_orgman_get_org_additional_info($org_id, 'Product Segments', $lang);

                  $categories = [];

                  if (isset($company_attributes) && !empty($company_attributes)) {
                    $categories[] = wicket_orgman_transform_section_data($company_attributes, __('Company Attributes', 'wicket-acc'));
                  }

                  if (isset($certifications) && !empty($certifications)) {
                    $categories[] = wicket_orgman_transform_section_data($certifications, __('Certifications', 'wicket-acc'));
                  }

                  if (isset($business_services) && !empty($business_services)) {
                    $categories[] = wicket_orgman_transform_section_data(
                      $business_services,
                      __('Business Services', 'wicket-acc'),
                      __('What type of business services do you offer?', 'wicket-acc')
                    );
                  }

                  if (isset($interests) && !empty($interests)) {
                    $categories[] = wicket_orgman_transform_section_data(
                      $interests,
                      __('Interests', 'wicket-acc'),
                      __('Select all options below that apply to your business.', 'wicket-acc')
                    );
                  }

                  if (isset($product_segments) && !empty($product_segments)) {
                    $categories[] = wicket_orgman_transform_section_data(
                      $product_segments,
                      __('Product Segments', 'wicket-acc'),
                      __('If you sell products, what segments of the natural organic wellness industry does your products represent? Select all that apply to your business.', 'wicket-acc')
                    );
                  }

                  // Filter out any null values from failed transformations
                  $categories = array_filter($categories);

                  if (!empty($categories)) {
                  ?>
                    <?php wicket_orgman_render_business_categories($categories_section['title'], $categories_section['description'], $categories); ?>
                  <?php
                  }
                  ?>
                </div> <!-- / .business-categories -->

                <div class="mt-5 mb-2">
                  <button class="button button-primary transition-all ease-in-out duration-600 text-base" type="submit" form="business-info-form"
                    data-loading-class="acc-force-hidden"
                    data-loading-aria-busy
                    data-loading-disable>
                    <?php esc_html_e('Save Business Information', 'wicket-acc'); ?>
                  </button>
                  <div class="acc-spinner transition-all ease-in-out duration-600"
                    data-loading>
                    <svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <style>
                        .spinner_ajPY {
                          transform-origin: center;
                          animation: spinner_AtaB .75s infinite linear
                        }

                        @keyframes spinner_AtaB {
                          100% {
                            transform: rotate(360deg)
                          }
                        }
                      </style>
                      <path d="M12,1A11,11,0,1,0,23,12,11,11,0,0,0,12,1Zm0,19a8,8,0,1,1,8-8A8,8,0,0,1,12,20Z" opacity=".25" />
                      <path d="M10.14,1.16a11,11,0,0,0-9,8.92A1.59,1.59,0,0,0,2.46,12,1.52,1.52,0,0,0,4.11,10.7a8,8,0,0,1,6.66-6.61A1.42,1.42,0,0,0,12,2.69h0A1.57,1.57,0,0,0,10.14,1.16Z" class="spinner_ajPY" />
                    </svg>
                  </div>
                </div>

                <div id="business-form-response"></div>

              </form>

            <?php else : ?>

              <?php
              if ($org_ids) {
                echo "<h2 class='primary_link_color'>" . __('Choose an Organization:', 'wicket-acc') . "</h2>";
                echo "<ul>";
                // lookup org details based on UUID found on the role
                foreach ($org_ids as $org_uuid) {
                  $organization = $client->get("organizations/$org_uuid");
                  echo "<li>";
                  echo "<a class='primary_link_color' href='" . home_url(add_query_arg([], $wp->request)) . "/?org_id=$org_uuid'>";
                  echo $organization['data']['attributes']['legal_name_' . $lang];
                  echo "</a>";
                  echo "</li>";
                }
                echo '</ul>';
              } else {
                echo "<p>" . __('You currently have no organizations to manage information for.', 'wicket-acc') . "</p>";
              }
              ?>

            <?php endif; ?>

          </div> <!-- / .wicket-acc-orgman -->
        </div> <!-- / .wicket-acc-page -->

        <?php WACC()->renderAccSidebar(); ?>
      </section>
    </main>
<?php endwhile;
endif; ?>

<script>
  /**
   * Handle "Other" checkbox functionality
   */
  (function() {
    document.addEventListener('DOMContentLoaded', function() {
      const sections = document.querySelectorAll('.section__content');

      sections.forEach(section => {
        const otherCheckboxes = section.querySelectorAll('.other-checkbox');

        otherCheckboxes.forEach(otherCheckbox => {
          const otherField = otherCheckbox.closest('.form-check').querySelector('.other-field');

          if (otherCheckbox && otherField) {
            // Initial state
            otherField.classList.toggle('acc-hidden', !otherCheckbox.checked);

            // Handle changes
            otherCheckbox.addEventListener('change', function() {
              otherField.classList.toggle('acc-hidden', !this.checked);
              if (!this.checked) {
                // Clear the input when unchecked
                otherField.querySelector('input').value = '';
              } else {
                // Focus the input when checked
                otherField.querySelector('input').focus();
              }
            });
          }
        });
      });
    });

    // On #business-info-form form change, empty #business-form-response
    const form = document.getElementById('business-info-form');
    const response = document.querySelector('#business-form-response');
    if (form && response) {
      form.addEventListener('change', function() {
        response.innerHTML = '';
      });
    }
  })();
</script>

<?php get_footer(); ?>
