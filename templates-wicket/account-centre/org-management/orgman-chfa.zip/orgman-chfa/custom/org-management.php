<?php

// No direct access
defined('ABSPATH') || exit;

/**
 * Profile for Wicket Account Centre
 *
 * Manage all actions of user's profile on WordPress.
 */

add_action('init', function () {
  // Make these variables available on the global scope
  global $orgman_pages_slugs, $orgman_pages_url, $orgman_business_info_values_map, $orgman_business_info_section_key_map, $orgman_business_info_section_key_map, $orgman_business_types, $orgman_business_docs_map;

  $orgman_pages_slugs = [
    'management',
    'members',
    'profile',
    'roster',
    'subsidiaries',
    'subsidiaries-add-new',
    'business-documents',
    'business-information',
    'business-information-retail',
  ];

  $orgman_pages_url = [
    'management'                  => wicket_orgman_get_page_url('management'),
    'profile'                     => wicket_orgman_get_page_url('profile'),
    'members'                     => wicket_orgman_get_page_url('members'),
    'roster'                      => wicket_orgman_get_page_url('roster'),
    'subsidiaries'                => wicket_orgman_get_page_url('subsidiaries'),
    'subsidiaries-add-new'        => wicket_orgman_get_page_url('subsidiaries-add-new'),
    'business-documents'          => wicket_orgman_get_page_url('business-documents'),
    'business-information'        => wicket_orgman_get_page_url('business-information'),
    'business-information-retail' => wicket_orgman_get_page_url('business-information-retail'),
  ];

  $orgman_business_types = [
    "retailer" => "Retailer",
    "manufacturer" => "Manufacturer",
    "manufacturer-direct-to-consumer" => "Manufacturer with Direct to Consumer (D2C)",
    "broker-distributor-wholesaler" => "Broker/Distributor/Wholesaler",
    "finished-product-importer-exporter" => "Finished Product Importer/Exporter",
    "health-practitioner" => "Health Practitioner",
    "b2b-vendor-services-investors" => "B2B Vendor Services/Investors",
    "not-for-profit-govt" => "Not-for-Profit/Government",
    "media" => "Media",
    "ingredient-supplier" => "Ingredient Supplier",
    "clinic" => "Clinic",
  ];

  $orgman_business_docs_map = [
    'retailer' => [
        'Business License',
        'Vendor Permit',
        'Business Registration',
        'Articles of Incorporation'
    ],
    'manufacturer' => [
        'Business License',
        'Articles of Incorporation',
        'Business Registration',
        'Organic Certificate' => ['optional' => true],
        'Site Licenses' => ['optional' => true],
        'Product Licenses' => ['optional' => true],
        'Medical Device Certification' => ['optional' => true]
    ],
    'manufacturer-direct-to-consumer' => [
        'Business License',
        'Articles of Incorporation',
        'Business Registration',
        'Organic Certificate' => ['optional' => true],
        'Site Licenses' => ['optional' => true],
        'Product Licenses' => ['optional' => true],
        'Medical Device Certification' => ['optional' => true]
    ],
    'broker-distributor-wholesaler' => [
        'Business License',
        'Articles of Incorporation',
        'Business Registration'
    ],
    'finished-product-importer-exporter' => [
        'Business License',
        'Articles of Incorporation',
        'Business Registration',
        'Organic Certificate' => ['optional' => true],
        'Site Licenses' => ['optional' => true],
        'Product Licenses' => ['optional' => true],
        'Medical Device Certification' => ['optional' => true]
    ],
    'health-practitioner' => [
        'Credentials',
        'Articles of Incorporation'
    ],
    'b2b-vendor-services-investors' => [
        'Business License',
        'Articles of Incorporation',
        'Business Registration'
    ],
    'not-for-profit-govt' => [
        'NFP Certificate'
    ],
    'media' => [
        'NFP Certificate'
    ],
    'ingredient-supplier' => [
        'Business License',
        'Articles of Incorporation',
        'Business Registration',
        'Safe Food For Canadians License',
        'Organic Certificate' => ['optional' => true],
        'Site Licenses' => ['optional' => true],
        'Product Licenses' => ['optional' => true]
    ],
    'clinic' => [
        'Business License',
        'Vendor Permit',
        'Business Registration',
        'Main Practitioner Credentials',
        'Articles of Incorporation'
    ]
  ];

  $orgman_business_info_values_map = [
    'other' => 'other',
    // Company Attributes
    'lgbtqia'        => '2slgbtqia-owned',
    'bipoc'          => 'bipoc-owned',
    'quebec-based'   => 'quebec-based-business',
    'family-owned'   => 'family-owned',
    'made-in-canada' => 'made-in-canada',
    'women-owned'    => 'women-owned',
    // Certifications
    'cardbon-neutral'                => 'carbon-neutral',
    'certified-b-corp'               => 'certified-b-corp',
    'cruelty-free'                   => 'cruelty-free',
    'ecocert'                        => 'ecocert',
    'fair-trade-certified'           => 'fair-trade-certified',
    'non-gmo-certified'              => 'non-gmo-certified',
    'nsf-certified'                  => 'nsf-certified',
    'organic-certified'              => 'organic-certified',
    'regenerative-organic-certified' => 'regenerative-organic-certified',
    'sustainably-sourced'            => 'sustainably-sourced',
    // Business Services
    'certification-services'        => 'certification-services',
    'consulting-services'           => 'consulting-services',
    'contract-manufacturing'        => 'contract-manufacturing',
    'display-fixtures'              => 'display-fixtures',
    'financial-services-investment' => 'financial-services-investment-firm',
    'ingredients-raw-materials'     => 'ingredients-raw-materials-supplier',
    'legal-regulatory'              => 'legal-regulatory-services',
    'marketing-advertising'         => 'marketing-advertising',
    'packaging-labeling'            => 'packaging-labeling',
    'quality-assurance-testing'     => 'quality-assurance-laboratory-testing',
    'r-d-formulation-flavouring'    => 'rd-formulation-flavouring',
    'research-data-services'        => 'research-data-services',
    'retail-services'               => 'retail-services',
    'shipping-logistics'            => 'shipping-logistics',
    'technology-solutions'          => 'technology-solutions',
    // Product Segments
    'food-beverage'           => 'food-beverage',
    'personal-care-beauty'    => 'personal-care-beauty',
    'health-home-lifestyle'   => 'healthy-home-lifestyle',
    'natural-health-products' => 'natural-health-products-vitamin-herbal-supplements',
    'pet-food-wellness'       => 'pet-food-wellness-supplies',
    // Retail Presence
    'store|online' => 'store-online',
  ];

  // Map section names to their API counterparts
  $orgman_business_info_section_key_map = [
    'company-attributes' => 'orgcompattributes',
    'certifications'     => 'orgcertifications',
    'business-services'  => 'orgbusservice',
    'product-segments'   => 'orgprodsegment',
    'retail-presence'    => 'orgretailpres',
    'operational-status' => 'orgopstatus',
    'number-of-employees' => 'orgnumemp',
  ];
});

/**
 * Load Org Management assets
 *
 * @return void
 */
function wicket_acc_orgman_load_assets()
{
  global $post;

  // Only if post type is my-account
  if ($post->post_type !== 'my-account') {
    return;
  }

  // On header, defer loading
  $jsArgs = [
    'defer' => true,
  ];
  wp_enqueue_script('htmx', 'https://unpkg.com/htmx.org@2', [], '2.0.3', $jsArgs);
  wp_enqueue_script('htmx-loading-states', 'https://unpkg.com/htmx-ext-loading-states@2', ['htmx'], '2.0.3', $jsArgs);
}
add_action('wp_enqueue_scripts', 'wicket_acc_orgman_load_assets');

/**
 * Filter wicket/acc/orgman/is_orgmanagement_page to add new custom templates:
 *
 * - subsidiaries.php
 * - subsidiaries-add-new.php
 *
 * @param string|bool $is_acc_template Template slug or false
 * @param int $post_id Post ID
 *
 * @return string|bool
 */
function wicket_acc_orgman_is_orgmanagement_page($is_acc_template, $post_id)
{
  // Is post_id custom post type my-account?
  if (get_post_type($post_id) !== 'my-account') {
    return false;
  }

  // Our page slug is organization-* ?
  $page_slug = sanitize_text_field(get_post_field('post_name', $post_id));

  // Starts with 'organization-'
  if (str_starts_with($page_slug, 'organization-')) {
    // Use the rest of the slug as template name
    $template_name = str_replace('organization-', '', $page_slug);

    return $template_name;
  }
}
add_filter('wicket/acc/orgman/is_orgmanagement_page', 'wicket_acc_orgman_is_orgmanagement_page', 10, 2);

/**
 * Get an Org Management page URL, by slug
 *
 * @param string $slug The page slug
 *
 * @return string The URL
 */
function wicket_orgman_get_page_url($slug = '', $noParams = false)
{
  global $orgman_pages_slugs;

  if (empty($slug)) {
    return home_url();
  }

  // Valid slug?
  if (!in_array($slug, $orgman_pages_slugs)) {
    return home_url();
  }

  if (did_action('acf/init')) {
    $page_id = get_field('acc_page_orgman-' . sanitize_text_field($slug), 'option');
  } else {
    $page_id = get_option('acc_page_orgman-' . sanitize_text_field($slug));
  }

  // Not found? Try to found the page by slug: organization-{slug}
  if (!$page_id) {
    $page_id = get_page_by_path('organization-' . sanitize_text_field($slug), OBJECT, 'my-account');
    $page_id = $page_id ? $page_id->ID : false;
  }

  // Not found again?
  if (!$page_id) {
    return home_url();
  }

  $page_url = get_permalink($page_id);

  // Check if we have URL params in the current URL, and add them to the URL
  if (strpos($_SERVER['REQUEST_URI'], '?') !== false && !$noParams) {
    // Catch all URL params
    $query_params = parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY);
    $url_params   = [];
    parse_str($query_params, $url_params);

    if (!empty($url_params)) {
      $page_url = add_query_arg($url_params, $page_url);
    }
  }

  return $page_url;
}

/**
 * Add or update a person to the membership
 *
 * @param array $args The arguments
 *
 * @return array|void The response: success (bool), error (bool), message (string). Void: url redirect
 */
function wicket_orgman_add_or_update_member($args)
{
  if (empty($args)) {
    return false;
  }

  global $wp;

  $client               = WACC()->MdpApi->init_client();
  $action               = isset($args['action']) ? sanitize_text_field($args['action']) : '';
  $lang                 = defined('ICL_LANGUAGE_CODE') ? ICL_LANGUAGE_CODE : 'en';
  $person_email         = isset($args['person_email']) ? sanitize_email($args['person_email']) : '';
  $person_role          = $args['person_role'] ?? '';
  $person_relationship  = isset($args['person_relationship']) ? sanitize_text_field($args['person_relationship']) : '';
  $org_id               = isset($args['org_id']) ? sanitize_text_field($args['org_id']) : '';
  $organization_obj     = wicket_get_organization($org_id);
  $organization_name    = $organization_obj['data']['attributes']['legal_name_' . $lang];
  $membership_id        = isset($args['membership_id']) ? sanitize_text_field($args['membership_id']) : '';
  $org_membership       = $client->get("organization_memberships/$membership_id?include=membership");
  $included_id          = isset($args['included_id']) ? sanitize_text_field($args['included_id']) : '';
  $person_first_name    = isset($args['first_name']) ? sanitize_text_field($args['first_name']) : '';
  $person_last_name     = isset($args['last_name']) ? sanitize_text_field($args['last_name']) : '';
  $person_phone         = isset($args['phone']) ? sanitize_text_field($args['phone']) : '';
  $person_current_roles = isset($args['person_current_roles']) ? sanitize_text_field($args['person_current_roles']) : '';
  $update_role_user_id  = isset($args['update_role_user_id']) ? sanitize_text_field($args['update_role_user_id']) : '';

  // Check if the user already exists in Wicket, by email
  $person = wicket_orgman_get_person_by_email($person_email);

  // Adding member and no relationship?
  if ($action == 'add_member_to_roster' && empty($person_relationship)) {
    return [
      'success' => false,
      'error'   => true,
      'message' => __('You must select a relationship type', 'wicket'),
    ];
  }

  // Person does not exist on MDP, create it
  if (!isset($person['id']) || empty($person['id'])) {
    $person = wicket_orgman_create_or_get_person(trim($_POST['given_name']), trim($_POST['family_name']), $person_email);

    // Get person ID
    $person_uuid = $person['data']['id'];
  } else {
    // Get person ID
    $person_uuid = $person['id'];
  }

  /*
  Add person phone.
  Payload to mimic:

  {"data":{"type":"phones","attributes":{"number":"6135551234","type":"work"}}}
  */
  if ($person_phone) {
    // Remove + from phone number
    $person_phone = str_replace('+', '', $person_phone);

    $phone_payload = [
      'data' => [
        'type' => 'phones',
        'attributes' => [
          'number' => $person_phone,
          'type'   => 'work'
        ]
      ]
    ];

    $person_phone = wicket_create_person_phone($person_uuid, $phone_payload);
  }

  // This is the only data we need from org on this call. Date format: ISO8604
  $start_at = $organization_obj['data']['attributes']['starts_at'] = (new \DateTime(date('c'), wp_timezone()))->format('c');
  //$ends_at  = $organization_obj['data']['attributes']['ends_at']   = (new \DateTime(date('c'), wp_timezone()))->modify('+1 year')->format('c');
  // PAO: no end date
  $ends_at = null;

  // PAO: no end date
  $org_membership['data']['attributes']['ends_at'] = null;

  // Assign this person to Org Membership
  $mdp_response = wicket_assign_person_to_org_membership(
    $person_uuid,
    $included_id,
    $membership_id,
    $org_membership
  );

  // If empty or null response, show error message
  if (empty($mdp_response) || is_null($mdp_response)) {
    $payload_log = [$person_uuid, $included_id, $membership_id, $org_membership];

    wc_get_logger()->debug('wicket_orgman_add_or_update_member > wicket_assign_person_to_org_membership: ' . print_r($mdp_response, true) . '<br/>With payload: ' . print_r($payload_log, true), ['source' => 'wicket_org_management']);

    return [
      'success' => false,
      'error'  => true,
      'message' => __("Error assigning person to membership", 'wicket'),
    ];
  }

  // Create or get the user on WP
  $user_wp = wicket_orgman_create_wp_user($person_uuid, $person_first_name, $person_last_name, $person_email);

  if ($user_wp === false) {
    return [
      'success' => false,
      'error'  => true,
      'message' => __("Error creating user on WP", 'wicket'),
    ];
  }

  // Other roles
  if ($action == 'add_member_to_roster') {
    if (!is_array($person_role)) {
      $person_role = [$person_role];
    }

    foreach ($person_role as $role) {
      wicket_assign_role($person_uuid, $role, $org_id);
    }

    wicket_orgman_assign_wp_roles($person_uuid, $person_role);
  } else {
    if (!is_array($person_current_roles)) {
      $person_current_roles = [$person_current_roles];
    }
    // action == update_member_on_roster
    wicket_remove_role($update_role_user_id, $person_current_roles);
    wicket_assign_role($update_role_user_id, $person_role, $org_id);
    wicket_orgman_assign_wp_roles($update_role_user_id, $person_role);
  }

  // Deal with the relationship on MDP
  $payload = [
    'data' => [
      'attributes' => [
        'connection_type'   => 'person_to_organization',
        'custom_data_field' => null,
        'description'       => null,
        'ends_at'           => $ends_at,
        'starts_at'         => $start_at,
        'tags'              => [],
        'type'              => $person_relationship,
      ],
      'id' => null,
      'relationships' => [
        'from' => [
          'data' => [
            'id'   => $person_uuid,
            'type' => 'people',
          ],
        ],
        'to' => [
          'data' => [
            'id' => $org_id,
            'meta' => [
              'ancestry_depth' => 0,
              'can_manage'     => true,
              'can_update'     => true,
            ],
            'type' => 'organizations',
          ],
        ],
      ],
      'type' => 'connections',
    ],
  ];

  // Create the connection
  $response_relationship = wicket_create_connection($payload);

  // If empty or null response, show error message
  if (empty($response_relationship) || is_null($response_relationship)) {
    wc_get_logger()->debug('wicket_orgman_add_or_update_member > wicket_create_connection: ' . print_r($response_relationship, true) . '<br/>With payload: ' . print_r($payload, true), ['source' => 'wicket_org_management']);

    return [
      'success' => false,
      'error'  => true,
      'message' => __("Error assigning person to membership", 'wicket'),
    ];
  }

  // Touchpoints
  if ($action == 'update_member_on_roster') {
    $params = [
      'person_id' => $person_uuid,
      'action'    => 'Organization membership updated',
      'details'   => "Person's role was set to '$_POST[role]' on " . date('c', time()),
      'data'      => ['org_id' => $org_id],
    ];

    $service_id = get_create_touchpoint_service_id('Roster Management', 'Updated member role');

    write_touchpoint($params, $service_id);
  }

  if ($action == 'add_member_to_roster') {
    $service_id        = get_create_touchpoint_service_id('Roster Management', 'Added member from Roster Management front.');

    $params = [
      'person_id' => $person_uuid,
      'action'    => 'Organization membership assigned',
      'details'   => "Person was assigned to a membership under '$organization_name' on " . date('c', time()),
      'data'      => ['org_id' => $org_id],
    ];

    write_touchpoint($params, $service_id);
  }

  // Send email to user letting them know of the assignment
  wicket_orgman_send_person_to_org_assignment_email($person_uuid, $org_id);

  // Redirect user
  $url_redirect = home_url(add_query_arg([], $wp->request));

  header("Location: $url_redirect?org_id=$org_id&membership_id=$membership_id&included_id=$included_id&success=true");

  die();
}

/**
 * Unassign person from an org membership/team
 *
 * @param array $args The arguments
 *
 * @return array|void The response: success (bool), error (bool), message (string). Void: url redirect
 */
function wicket_orgman_unassign_person_uuid($args = [])
{
  /*
    Data from URL:

    $unassign_url = home_url(add_query_arg(array(), $wp->request)) . '/?org_id=' . $org_id . '&membership_id=' . $membership_id . '&person_membership_uuid=' . $person_membership_uuid . '&unassign_person_uuid=' . $person_uuid . '&person_relationship=' . $person_relationship_slug . '&person_connection_id=' . $person_connection_id;
    */

  global $wp;

  $lang                   = defined('ICL_LANGUAGE_CODE') ? ICL_LANGUAGE_CODE : 'en';
  $unassign_person_uuid   = isset($args['unassign_person_uuid']) ? sanitize_text_field($args['unassign_person_uuid']) : '';
  $person_uuid            = isset($args['person_uuid']) ? sanitize_text_field($args['person_uuid']) : '';
  $person_email           = base64_decode(urldecode($_GET['email']));
  $person_relationship    = isset($args['person_relationship']) ? sanitize_text_field($args['person_relationship']) : '';
  $person_connection_id   = isset($args['person_connection_id']) ? sanitize_text_field($args['person_connection_id']) : '';
  $org_id                 = isset($args['org_id']) ? sanitize_text_field($args['org_id']) : '';
  $membership_id          = isset($args['membership_id']) ? sanitize_text_field($args['membership_id']) : '';
  $included_id            = isset($args['included_id']) ? sanitize_text_field($args['included_id']) : '';
  $allowed_roles          = $args['allowed_roles'] ?? [];
  $allowed_relationships  = $args['allowed_relationships'] ?? [];
  $person_membership_uuid = isset($args['person_membership_uuid']) ? sanitize_text_field($args['person_membership_uuid']) : '';

  // Decode base64 params
  $person_relationship = base64_decode(urldecode($person_relationship));

  $missing_args = [];
  if (!$person_email) {
    $missing_args[] = 'person_email';
  }
  if (!$person_uuid) {
    $missing_args[] = 'person_uuid';
  }
  if (!$person_relationship) {
    $missing_args[] = 'person_relationship';
  }
  if (!$person_connection_id) {
    $missing_args[] = 'person_connection_id';
  }
  if (!$org_id) {
    $missing_args[] = 'org_id';
  }
  if (!$membership_id) {
    $missing_args[] = 'membership_id';
  }
  if (!$included_id) {
    $missing_args[] = 'included_id';
  }
  if (!$unassign_person_uuid) {
    $missing_args[] = 'unassign_person_uuid';
  }

  if (!empty($missing_args)) {
    return [
      'success' => false,
      'error'  => true,
      'message' => sprintf(__('Missing arguments: %s', 'wicket'), implode(', ', $missing_args)),
    ];
  }

  $organization_obj       = wicket_get_organization($org_id);
  $organization_name      = $organization_obj['data']['attributes']['legal_name_' . $lang];
  $person                 = wicket_get_person_by_id($person_uuid);

  // Don't allow removing membership_owner
  if (in_array('membership_owner', $person->role_names)) {
    return [
      'success' => false,
      'error'  => true,
      'message' => __('Error: You cannot remove a membership owner from the organization', 'wicket'),
    ];
  }

  // Has current relationship = president
  if (isset($person_relationship) && $person_relationship == 'president') {
    return [
      'success' => false,
      'error'  => true,
      'message' => __('Error: You cannot remove a president from the organization', 'wicket'),
    ];
  }

  // Remove all roles
  foreach ($allowed_roles as $dropdown_key => $dropdown_label) {
    wicket_remove_role($unassign_person_uuid, $dropdown_key);
  }

  // From WP too
  wicket_orgman_remove_wp_roles($unassign_person_uuid, $allowed_roles);

  // Remove membership
  // wicket_unassign_person_from_org_membership($_GET['person_membership_uuid']);
  // PAO: set membership pend date to today
  $end_date = date('Y-m-d');
  $response_membership = wicket_orgman_update_person_membership_date($person_membership_uuid, [
    'ends_at' => $end_date,
  ]);

  // Remove connection (relationship)
  //$response_connection = wicket_remove_connection($person_connection_id);
  // PAO: We won't remove the connection. We will set the end_date to today's date
  $response_relationship = wicket_set_connection_start_end_dates($person_connection_id, $end_date);

  if (is_wp_error($response_membership) || is_wp_error($response_relationship)) {
    return [
      'success' => false,
      'error'  => true,
      'message' => __('Error updating membership or connection end date', 'wicket'),
    ];
  }

  // Touchpoint
  $params = [
    'person_id' => $unassign_person_uuid,
    'action'    => 'Organization membership removed',
    'details'   => "Persons membership was removed from '$organization_name' on " . date('c', time()),
    'data'      => ['org_id' => $org_id],
  ];

  $service_id = get_create_touchpoint_service_id('Roster Manage', 'Removed member from organization');

  write_touchpoint($params, $service_id);

  // Redirect user
  $url_redirect = home_url(add_query_arg([], $wp->request));

  header("Location: $url_redirect?org_id=$org_id&membership_id=$membership_id&included_id=$included_id");

  die();
}

/**
 * Update person roles
 *
 * @param array $args The arguments
 *
 * @return array|void The response: success (bool), error (bool), message (string). Void: url redirect
 */
function wicket_orgman_update_role($args)
{
  if (empty($args)) {
    return [
      'success' => false,
      'error'  => true,
      'message' => __('Missing arguments', 'wicket'),
    ];
  }

  global $wp;

  $person_current_roles    = isset($args['person_current_roles']) ? sanitize_text_field($args['person_current_roles']) : '';
  $new_role                = $args['role'] ?? '';
  $org_id                  = isset($args['org_id']) ? sanitize_text_field($args['org_id']) : '';
  $update_role_person_uuid = isset($args['update_role_person_uuid']) ? sanitize_text_field($args['update_role_person_uuid']) : '';
  $membership_id           = isset($args['membership_id']) ? sanitize_text_field($args['membership_id']) : '';
  $included_id             = isset($args['included_id']) ? sanitize_text_field($args['included_id']) : '';

  // Remove current role(s), wicket_remove_role(). Get current role.
  if (str_contains($person_current_roles, ',')) {
    $person_current_roles = explode(',', $person_current_roles);
  } else {
    $person_current_roles = [$person_current_roles];
  }

  if (!is_array($new_role)) {
    $new_role = [$new_role];
  }

  // PAO: We should never remove the user role 'member'
  $roles_to_remove = array_diff($person_current_roles, ['member']);

  // PAO: new role should always be 'member'
  $new_role = array_merge($new_role, ['member']);

  // Remove roles
  foreach ($roles_to_remove as $role_remove) {
    wicket_remove_role($update_role_person_uuid, $role_remove);
  }

  // From WP too
  wicket_orgman_remove_wp_roles($update_role_person_uuid, $roles_to_remove);

  // Add new roles
  foreach ($new_role as $role_add) {
    wicket_assign_role($update_role_person_uuid, $role_add, $org_id);
  }

  // From WP too
  wicket_orgman_assign_wp_roles($update_role_person_uuid, $new_role);

  // Touchpoint
  $params = [
    'person_id' => $_GET['update_role_person_uuid'],
    'action'    => 'Organization member updated',
    'details'   => "Person's role was updated from '$person_current_roles' to '$new_role' on " . date('c', time()),
    'data'      => ['org_id' => $org_id],
  ];

  $service_id = get_create_touchpoint_service_id('Roster Manage', 'Updated member role');

  write_touchpoint($params, $service_id);

  // Redirect user
  $url_redirect = home_url(add_query_arg([], $wp->request));

  header("Location: $url_redirect?org_id=$org_id&membership_id=$membership_id&included_id=$included_id");

  die();
}

/**
 * Returns the Org membership UUID for the given organization UUID
 *
 * @param array $data The JSON API response data
 */
function wicket_orgman_get_membership_uuid_by_organization_uuid($org_id = '')
{
  if (!function_exists('wicket_get_current_person_memberships')) {
    return null;
  }

  if (empty($org_id)) {
    return null;
  }

  $memberships = wicket_get_current_person_memberships();

  // Iterate over the included array, and find relationships>organization>data>id that matches the given org_id
  foreach ($memberships['included'] as $included) {
    if ($included['type'] === 'organization_memberships') {
      if (
        isset($included['relationships']['organization']['data']['id']) &&
        $included['relationships']['organization']['data']['id'] === $org_id
      ) {
        // Get relationships>membership>data>id
        if (isset($included['relationships']['membership']['data']['id'])) {
          return $included['relationships']['membership']['data']['id'];
        } else {
          return null;
        }
      }
    }
  }

  return null;
}

/**
 * Return the membership ID for this person and organization
 *
 * @param string $organization_uuid The organization UUID
 *
 * @return string|bool The membership ID or false if not found
 */
function wicket_orgman_get_current_person_memberships_by_organization($organization_uuid = '')
{
  if (!$organization_uuid) {
    return false;
  }

  $memberships = wicket_get_current_person_memberships();


  if (empty($memberships['included']) || !is_array($memberships['included'])) {
    return false;
  }

  // Iterate over the included array to find the organization_membership related to the given org UUID
  foreach ($memberships['included'] as $included) {
    if ($included['type'] === 'organization_memberships') {
      // Check if the organization UUID matches
      if (
        isset($included['relationships']['organization']['data']['id']) &&
        $included['relationships']['organization']['data']['id'] === $organization_uuid
      ) {
        // Return the UUID of the organization_membership itself
        return $included['id'];
      }
    }
  }

  return false;
}

/**
 * Return a person object by email. If the email is not found, return false.
 *
 * @param string $email Email address of the person
 *
 * @return object|bool Person object or false if not found
 */
function wicket_orgman_get_person_by_email($email = '')
{
  if (!$email) {
    return false;
  }

  $client = WACC()->MdpApi->init_client();
  $person = $client->get('/people?filter[emails_primary_eq]=true&filter[emails_address_eq]=' . urlencode($email));

  // Return the first person if found
  if (isset($person['data'][0])) {
    return $person['data'][0];
  }

  return false;
}

/**
 * Return Org membership_uuid information
 */
function wicket_orgman_get_org_membership_data($membership_uuid = '')
{
  if (!$membership_uuid) {
    return false;
  }

  $client   = wicket_api_client();
  $response = $client->get('/organization_memberships/' . $membership_uuid);

  // Return the count of assigned people if found
  if (isset($response['data'])) {
    return $response['data'];
  }

  return false;
}

/**
 * Returns an array of all the organization memberships person
 *
 * @param string $membership_uuid The membership UUID
 *
 * @return array|bool The organization memberships or false if not found
 */
function wicket_orgman_get_org_membership_members($membership_uuid = '')
{
  if (!$membership_uuid) {
    return false;
  }

  $client = wicket_api_client();
  $response = $client->get('/organization_memberships/' . $membership_uuid . '/person_memberships');

  // Return the count of max_assignments if found
  if (isset($response['data'])) {
    return $response['data'];
  }

  return false;
}

/**
 * Returns an array of all the organization relationships (person only)
 *
 * Different from the base plugin helper:
 * - It returns the relationships of the organization, not the person
 *
 * @param string $org_uuid The organization UUID
 *
 * @return array|bool The organization relationships or false if not found
 */
function wicket_orgman_get_org_relationships_person($org_uuid = '')
{
  if (!$org_uuid) {
    return false;
  }

  $client   = wACC()->MdpApi->init_client();
  $response = $client->get('/organizations/' . $org_uuid . '/connections?filter%5Bconnection_type_eq%5D=person_to_organization');

  // Return the count of max_assignments if found
  if (isset($response['data'])) {
    return $response['data'];
  }

  return false;
}

/**
 * Returns an array of all the users roles for an organization
 *
 * Different from the base plugin helper:
 *  - It returns the roles of the organization, not the person
 *
 * @param string $person_uuid The organization UUID

 * @param string $org_uuid The organization UUID
 *
 * @return array|bool The users org roles or false if not found
 */
function wicket_orgman_get_org_roles_person($person_uuid = '', $org_uuid = '')
{
  if (!$person_uuid || !$org_uuid) {
    return false;
  }

  $client   = wicket_api_client();
  $response = $client->get('/people/' . $person_uuid . '/roles');

  // Return the count of max_assignments if found
  if (isset($response['data'])) {
    foreach ($response['data'] as $role) {
      if (!empty($role['relationships']['resource']['data']['id']) && $role['relationships']['resource']['data']['id'] == $org_uuid) {
        $users_roles[] = $role['attributes']['name'];
      }
    }

    return $users_roles ?? [];
  }

  return false;
}

/**
 * Get organization info, extended
 *
 * Different from the base plugin helper:
 *  - It returns the main address, phone, and email
 *
 * @param string $org_uuid The organization UUID
 * @param string $lang The language code
 *
 * @return array|bool The organization basic info or false if not found
 */
function wicket_orgman_get_organization_info_extended($org_uuid = '', $lang = 'en')
{
  if (!$org_uuid || !$lang) {
    return false;
  }

  $org_info = wicket_get_organization_basic_info($org_uuid);
  $client   = WACC()->MdpApi->init_client();

  // Get Org main address
  $response = $client->get('/organizations/' . $org_uuid . '/addresses');

  // Add the main address to the org_info
  if (isset($response['data']) && !empty($response['data'])) {
    $org_info['org_meta']['main_address'] = $response['data'][0]['attributes'];
  } else {
    $org_info['org_meta']['main_address'] = [];
  }

  // Get Org telephone number
  $response = $client->get('/organizations/' . $org_uuid . '/phones');

  // Add the main address to the org_info
  if (isset($response['data']) && !empty($response['data'])) {
    $org_info['org_meta']['main_phone'] = $response['data'][0]['attributes'];
  } else {
    $org_info['org_meta']['main_phone'] = [];
  }

  // Get Org email address
  $response = $client->get('/organizations/' . $org_uuid . '/emails');

  // Add the main address to the org_info
  if (isset($response['data']) && !empty($response['data'])) {
    $org_info['org_meta']['main_email'] = $response['data'][0]['attributes'];
  } else {
    $org_info['org_meta']['main_email'] = [];
  }

  return $org_info;
}

/**
 * Sends an email to the user with instructions on how to access their team profile.
 *
 * @param string $person_uuid The person UUID
 * @param int $org_id The organization ID to send the email with the correct branding.
 *
 * @return void
 */
function wicket_orgman_send_person_to_org_assignment_email($person_uuid, $org_id)
{
  $org       = wicket_get_organization($org_id);
  $lang      = defined('ICL_LANGUAGE_CODE') ? ICL_LANGUAGE_CODE : 'en';
  $person    = wicket_get_person_by_id($person_uuid);
  $home_url  = get_home_url();
  $site_name = get_bloginfo('name');
  $site_url  = get_site_url();
  $base_domain = parse_url($site_url, PHP_URL_HOST);

  if ($org) {
    $organization_name = $org['data']['attributes']['legal_name_' . $lang];
  } else {
    $organization_name = $site_name;
  }

  $to         = $person->primary_email_address;
  $first_name = $person->given_name;
  $last_name  = $person->family_name;
  $subject    = "Welcome to " . $organization_name;

  $body = "Hi $first_name, <br>
  <p>You have been assigned a membership as part of $organization_name.</p>
  <p>You will receive an account confirmation email from chfa@wicketcloud.com, this will allow you to set your password and login for the first time.</p>
  <p>Going forward you can visit <a href='$home_url'>$site_name</a> and login to complete your profile and access your resources.</p>
	<br>
	Thank you,
	<br>
	$organization_name";

  $headers   = ['Content-Type: text/html; charset=UTF-8'];
  $headers[] = 'From: ' . $organization_name . ' <no-reply@' . $base_domain . '>';

  wp_mail($to, $subject, $body, $headers);
}

/**
 * Get person connections by ID
 *
 * @param string $uuid The person UUID
 *
 * @return array|bool The person connections or false if not found
 */
function wicket_orgman_get_person_connections_by_id($uuid)
{
  $client = wicket_api_client();

  $connections = $client->get('people/' . $uuid . '/connections?filter%5Bconnection_type_eq%5D=all&sort=-created_at');

  return $connections;
}

/**
 * Create a new user on WordPress
 *
 * @param string $uuid The UUID of the user, to be used as username
 * @param string $first_name The first name of the user
 * @param string $last_name The last name of the user
 * @param string $email The email address of the user
 *
 * @return array|bool The user object or false if not found
 */
function wicket_orgman_create_wp_user($uuid, $first_name, $last_name, $email)
{
  if (empty($uuid) || empty($first_name) || empty($last_name) || empty($email)) {
    return false;
  }

  $user = get_user_by('login', $uuid);

  if ($user) {
    return $user;
  }

  $user = get_user_by('email', $email);

  if ($user) {
    return $user;
  }

  // Create the user
  $username = sanitize_user($uuid);
  $password = wp_generate_password(12, false);
  $user_id  = wp_create_user($username, $password, $email);

  if (is_wp_error($user_id)) {
    return false;
  }

  return true;
}

/**
 * Assign WP roles to a user
 *
 * @param string $user The person UUID (login) or email address
 * @param array $roles The roles to assign. Can be an array or a string
 *
 * @return bool True if successful, false if not
 */
function wicket_orgman_assign_wp_roles($person_uuid, $roles)
{
  if (empty($person_uuid) || empty($roles)) {
    return false;
  }

  $user = get_user_by('login', $person_uuid) ?? get_user_by('email', $person_uuid);

  if (!$user || !is_object($user)) {
    return false;
  }

  if (is_array($roles)) {
    foreach ($roles as $role) {
      $user->add_role($role);
    }
  } else {
    $user->add_role($roles);
  }

  return true;
}

/**
 * Remove WP roles from a user
 *
 * @param string $user The person UUID (login) or email address
 * @param array $roles The roles to remove. Can be an array or a string
 *
 * @return bool True if successful, false if not
 */
function wicket_orgman_remove_wp_roles($person_uuid, $roles)
{
  if (empty($person_uuid) || empty($roles)) {
    return false;
  }

  $user = get_user_by('login', $person_uuid) ?? get_user_by('email', $person_uuid);

  if (!$user || !is_object($user)) {
    return false;
  }

  if (is_array($roles)) {
    foreach ($roles as $role) {
      $user->remove_role($role);
    }
  } else {
    $user->remove_role($roles);
  }

  return true;
}

/**
 * Role checker
 *
 * @param array|string $roles array or string of roles to check
 * @param bool $all_true Default: false. If true, all roles must be in the user's roles. If false, at least one role must be in the user's roles
 *
 * @return bool True if condition met, false if not
 */
function wicket_orgman_role_check($roles, $all_true = false)
{
  if (!is_array($roles)) {
    $roles = [$roles];
  }

  $user = wp_get_current_user();

  // Admins can do anything
  if (in_array('administrator', $user->roles)) {
    return true;
  }

  if ($all_true) {
    // Match all roles received
    $match_all = true;

    foreach ($roles as $role) {
      if (!in_array($role, $user->roles)) {
        $match_all = false;
        break;
      }
    }

    return $match_all;
  } else {
    // Match any role received, at least one of them
    foreach ($roles as $role) {
      if (in_array($role, $user->roles)) {
        return true;
      }
    }
  }

  return false;
}

/**
 * Role check for pages
 *
 * @param array|string $roles array or string of roles to check
 * @param bool $all_true If true, all roles must be in the user's roles. If false, at least one role must be in the user's roles
 *
 * @return void
 */
function wicket_orgman_page_role_check($roles, $all_true = false)
{
  $response = wicket_orgman_role_check($roles, $all_true);

  if (!$response) {
    wp_die(__('You do not have permission to access this page', 'wicket'));
  }
}

/**
 * Update person membership dates
 *
 * Different from the base plugin helper:
 *  - Dates are optional.
 *  - Start date isn't fixed to today.
 *
 * @param string $membership_uuid The membership UUID
 * @param array $args The arguments: starts_at, ends_at, grace_period_days
 *
 * @return array|bool The response or false if not successful
 */
function wicket_orgman_update_person_membership_date($membership_uuid, $args = [])
{
  if (empty($membership_uuid) || empty($args)) {
    return false;
  }

  $client = WACC()->MdpApi->init_client();

  $starts_at         = isset($args['starts_at']) ? sanitize_text_field($args['starts_at']) : '';
  $ends_at           = isset($args['ends_at']) ? sanitize_text_field($args['ends_at']) : '';
  $grace_period_days = isset($args['grace_period_days']) ? sanitize_text_field($args['grace_period_days']) : false;

  // Empty start and end? We need at least one of this
  if (empty($starts_at) && empty($ends_at)) {
    return false;
  }

  // Build membership payload
  $payload = [
    'data' => [
      'type' => 'person_memberships',
      'attributes' => [],
    ],
  ];

  // Only if dates are received
  if (!empty($starts_at)) {
    $payload['data']['attributes']['starts_at'] = $starts_at;
  }

  if (!empty($ends_at)) {
    $payload['data']['attributes']['ends_at'] = $ends_at;
  }

  // Grace period days
  if ($grace_period_days !== false) {
    $payload['data']['attributes']['grace_period_days'] = $grace_period_days;
  }

  try {
    $response = $client->patch("/person_memberships/$membership_uuid", ['json' => $payload]);
  } catch (Exception $e) {
    $response = new \WP_Error('wicket_api_error', $e->getMessage());
  }

  return $response;
}

/**
 * Retrieves a person by its ID.
 *
 * @param string $person_id The person ID.
 *
 * @return array|false The person data or false if not found.
 */
function wicket_orgman_get_person_by_id($person_id = '')
{
  if (!$person_id) {
    return false;
  }

  $person = wicket_get_person_by_id($person_id);

  if (!$person) {
    return false;
  }

  return $person;
}

/**
 * Retrieves the current person (logged in user).
 *
 * @return array|false The person data or false if not found.
 */
function wicket_orgman_get_current_person()
{
  $person = wicket_current_person();

  if (!$person) {
    return false;
  }

  return $person;
}

/**
 * Creates a new person or gets an existing one if it already exists.
 *
 * @param string $first_name The first name of the person.
 * @param string $last_name The last name of the person.
 * @param string $email The email address of the person.
 * @param array $extras Extra data to add to the person's profile.
 *
 * @return string|false The UUID of the person or false if the person could not be created or found.
 */
function wicket_orgman_create_or_get_person($first_name, $last_name, $email, $extras = [])
{
  if (!$first_name || !$last_name || !$email) {
    return false;
  }

  // Valid email?
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    return false;
  }

  // Does the person already exist?
  $person = wicket_orgman_get_person_by_email($email);

  if (!$person) {
    $person = wicket_create_person(trim($first_name), trim($last_name), trim($email));
  }

  if (!$person) {
    return false;
  }

  $person_id = $person['id'] ?? $person['data']['id'];

  // Add extra data
  if (!empty($extras)) {
    $update_response = wicket_orgman_update_person_profile_data($person_id, $extras);
  }

  /*
  Add person phone.
  Payload to mimic:

  {"data":{"type":"phones","attributes":{"number":"6135551234","type":"work"}}}
  */
  if (isset($extras['phone']) && !empty($extras['phone'])) {
    // Remove + from phone number
    $person_phone = str_replace('+', '', $extras['phone']);

    $phone_payload = [
      'data' => [
        'type' => 'phones',
        'attributes' => [
          'number' => $person_phone,
          'type'   => 'work'
        ]
      ]
    ];

    $person_phone = wicket_create_person_phone($person_id, $phone_payload);
  }

  return $person_id;
}

/**
 * Updates a person's profile data.
 *
 * Given a person UUID and an array of data to be updated,
 * this function sends a PATCH request to the Wicket API
 * to update the person's profile data.
 *
 * @param string $person_id The person UUID.
 * @param array  $data      An array of data to be updated.
 *
 * @return array|false The response from the Wicket API, false if the update fails.
 */
function wicket_orgman_update_person_profile_data($person_id, $data = [])
{
  if (empty($person_id) || empty($data)) {
    return false;
  }

  $client = WACC()->MdpApi->init_client();

  /**
   * Payload to mimic:
   *
   * {"data":{"type":"people","id":"0eaa4b70-9922-4195-a67f-cc16d8e86037","attributes":{"given_name":"First03","additional_name":null,"family_name":"Last03","suffix":null,"honorific_suffix":null,"preferred_pronoun":null,"job_title":"CEO","job_level":"director"}}}
   *
   * Send as PATCH to /people/{UUID}
   */

  $data = [
    'data' => [
      'type'       => 'people',
      'id'         => $person_id,
      'attributes' => $data,
    ],
  ];

  try {
    $response = $client->patch("/people/$person_id", ['json' => $data]);
  } catch (Exception $e) {
    $response = new \WP_Error('wicket_api_error', $e->getMessage());
  }

  return $response;
}

/**
 * Retrieves all job levels from MDP.
 *
 * @return array An associative array where the key is the job level slug and the value is an array with 'slug' and 'name' keys.
 */
function wicket_orgman_get_job_levels()
{
  $client = WACC()->MdpApi->init_client();

  $job_levels_resource_types = $client->get('/resource_types?filter[entity_type_code_eq]=shared_job_level');
  $job_levels = [];

  foreach ($job_levels_resource_types['data'] as $resource_type) {
    $job_levels[$resource_type['attributes']['slug']] = [
      'slug' => $resource_type['attributes']['slug'],
      'name' => $resource_type['attributes']['name'],
    ];
  }

  return $job_levels;
}

/**
 * Create a new connection in the API.
 *
 * @param array $payload The new connection properties.
 *
 * @return bool|array true on success,
 */
function wicket_orgman_create_connection($payload)
{
  $client = WACC()->MdpApi->init_client();

  try {
    $client->post('connections', ['json' => $payload]);

    return true;
  } catch (\Exception $e) {
    $errors = json_decode($e->getResponse()->getBody())->errors;
    echo "<pre>";
    print_r($e->getMessage());
    echo "</pre>";

    echo "<pre>";
    print_r($errors);
    echo "</pre>";

    $response = [
      'error'   => true,
      'message' => $errors[0]->detail,
    ];

    return $response;
  }

  return false;
}

/**
 * Builds a payload for creating a new connection of a given type between a person and an org.
 *
 * @param string $person_id The UUID of the person to connect to the org.
 * @param string $org_id The UUID of the org to connect the person to.
 * @param string $connection_type The type of connection to create. Ex: person_to_organization, organization_to_person, etc.
 *
 * @return array The payload for creating a new connection.
 */
function wicket_orgman_build_connection_payload($person_id = null, $org_id = null, $connection_type = null, $type = null)
{
  $payload = [
    'data' => [
      'type'          => 'connections',
      'attributes'    => [
        'connection_type' => $connection_type,
        'type'            => $type,
        'starts_at' => date("Y-m-d"),
      ],
      'relationships' => [
        'organization' => [
          'data' => [
            'id'   => $org_id,
            'type' => 'organizations',
          ],
        ],
        'person'       => [
          'data' => [
            'id'   => $person_id,
            'type' => 'people',
          ],
        ],
        'from'         => [
          'data' => [
            'id'   => $person_id,
            'type' => 'people',
          ],
        ],
        'to'           => [
          'data' => [
            'id'   => $org_id,
            'type' => 'organizations',
          ],
        ],
      ],
    ],
  ];

  return $payload;
}

/**
 * Returns a list of connection types for a person to an organization.
 *
 * @return array
 */
function wicket_orgman_get_person_to_organizations_connection_types_list()
{
  $client = WACC()->MdpApi->init_client();

  $resource_types = $client->resource_types->all();
  $resource_types = collect($resource_types);
  $found          = $resource_types->filter(function ($item) {
    return $item->resource_type == 'connection_person_to_organizations';
  });

  return $found;
}


/**
 * Returns resource list of person types.
 *
 * @return array
 */
function wicket_orgman_get_person_types_list()
{
  $client = WACC()->MdpApi->init_client();

  $resource_types = $client->resource_types->all();
  $resource_types = collect($resource_types);
  $found          = $resource_types->filter(function ($item) {
    return $item->resource_type == 'shared_person_type';
  });

  return $found;
}

/**
 * Get organization additional information
 *
 * @param string $org_uuid The organization UUID
 * @param string $segment The segment to get
 * @param string $lang The language code. Default: en
 *
 * @return array|bool The organization additional info or false if not found
 */
function wicket_orgman_get_org_additional_info($org_uuid = '', $segment = '', $lang = 'en')
{
  if (!$org_uuid || !$lang || !$segment) {
    return false;
  }

  $client = WACC()->MdpApi->init_client();

  $request = $client->get('/organizations/' . $org_uuid, [
    'query' => [
      'include' => 'addresses,emails,phones,webAddresses,roles,comments,pinnedComments.person,jsonSchemasAvailable,parentOrganization'
    ]
  ]);

  $response = is_array($request) ? $request : json_decode($request->getBody(), true);

  if (!isset($response['data']) || empty($response['data'])) {
    wc_get_logger()->error('Failed to get organization additional info', [
      'org_uuid' => $org_uuid,
      'segment' => $segment,
      'lang' => $lang,
      'error' => 'No data returned',
    ]);

    return false;
  }

  // Extract pre-checked attributes from data_fields
  $pre_checked_options = wicket_orgman_get_selected_values($response);

  $json_schemas = $response['included'] ?? [];

  foreach ($json_schemas as $schema) {
    if ($schema['type'] === 'json_schemas' && isset($schema['attributes']['ui_schema'])) {
      $ui_schema = $schema['attributes']['ui_schema'];
      $schema_data = $schema['attributes']['schema'] ?? [];

      // Check if the segment matches the schema title or key
      if (
        (isset($ui_schema['ui:i18n']['title'][$lang]) &&
          strtolower($ui_schema['ui:i18n']['title'][$lang]) === strtolower($segment)) ||
        (isset($schema['attributes']['key']) && $schema['attributes']['key'] === $segment)
      ) {
        $result = [
          'section' => [
            'title' => $ui_schema['ui:i18n']['title'][$lang] ?? '',
            'description' => $ui_schema['ui:i18n']['description'][$lang] ?? '',
            'schema_key' => $schema['attributes']['key'] ?? ''
          ],
          'fields' => [],
          'pre_checked_options' => $pre_checked_options
        ];

        // Process root level fields
        if (isset($schema_data['properties'])) {
          // Get the field order from ui:order if available
          $field_order = $ui_schema['ui:order'] ?? array_keys($schema_data['properties']);
          $ordered_fields = [];

          // Process fields in the specified order
          foreach ($field_order as $field_key) {
            if (!isset($schema_data['properties'][$field_key])) {
              continue;
            }

            $field_props = $schema_data['properties'][$field_key];
            $field_ui = $ui_schema[$field_key] ?? [];

            // For radio buttons (like operational status)
            if (isset($field_ui['ui:widget']) && $field_ui['ui:widget'] === 'radio') {
              $ordered_fields[$field_key] = [
                'name' => sanitize_title($segment),
                'type' => $field_props['type'] ?? 'radio',
                'title' => $field_ui['ui:i18n']['label'][$lang] ?? $field_props['title'] ?? '',  // Use the label instead of title
                'description' => $ui_schema[$field_key]['ui:i18n']['description'][$lang] ?? $field_props['description'] ?? '',
                'required' => in_array($field_key, $schema_data['required'] ?? []),
                'widget_type' => 'radio',
                'options' => isset($field_ui['ui:i18n']['enumNames'][$lang]) ? array_combine(
                  $field_props['enum'] ?? ['true', 'false'],
                  $field_ui['ui:i18n']['enumNames'][$lang]
                ) : [
                  'true' => __('Yes', 'wicket-acc'),
                  'false' => __('No', 'wicket-acc')
                ]
              ];
            }
            // For enum fields (like number of employees)
            elseif (isset($field_props['enum']) && !empty($field_props['enum'])) {
              $ordered_fields[$field_key] = [
                'name' => sanitize_title($segment),
                'type' => $field_props['type'] ?? 'number',
                'title' => $field_ui['ui:i18n']['label'][$lang] ?? $field_props['title'] ?? '',
                'description' => $ui_schema[$field_key]['ui:i18n']['description'][$lang] ?? $field_props['description'] ?? '',
                'required' => in_array($field_key, $schema_data['required'] ?? []),
                'widget_type' => 'select',
                'options' => isset($field_ui['ui:i18n']['enumNames'][$lang]) ? array_combine(
                  $field_props['enum'],
                  $field_ui['ui:i18n']['enumNames'][$lang]
                ) : array_combine($field_props['enum'], $field_props['enum'])
              ];
            }
            // For checkboxes (like business categories)
            elseif (isset($field_ui['ui:i18n']['enumNames'][$lang])) {
              $options = $field_ui['ui:i18n']['enumNames'][$lang];
              foreach ($options as $index => $label) {
                $value = sanitize_title($label);
                $result['attributes'][$value] = $label;
              }
            }
            // For text fields (like legal name)
            elseif ($field_props['type'] === 'string') {
              // Get value from data_fields if it exists
              $value = '';
              if (isset($response['data']['attributes']['data_fields'])) {
                foreach ($response['data']['attributes']['data_fields'] as $field) {
                  if ($field['key'] === strtolower($schema['attributes']['key'])) {
                    $value = $field['value'][$field_key] ?? '';
                    break;
                  }
                }
              }

              $ordered_fields[$field_key] = [
                'name' => sanitize_title($segment),
                'type' => $field_props['type'] ?? 'string',
                'title' => $field_ui['ui:i18n']['label'][$lang] ?? '',
                'description' => $ui_schema[$field_key]['ui:i18n']['description'][$lang] ?? $field_props['description'] ?? '',
                'required' => in_array($field_key, $schema_data['required'] ?? []),
                'widget_type' => isset($field_ui['ui:widget']) ? $field_ui['ui:widget'] : 'text',
                'value' => $value
              ];
            }
            // For number fields
            elseif ($field_props['type'] === 'integer' || $field_props['type'] === 'number') {
              // Get value from data_fields if it exists
              $value = '';
              if (isset($response['data']['attributes']['data_fields'])) {
                foreach ($response['data']['attributes']['data_fields'] as $field) {
                  if ($field['key'] === strtolower($schema['attributes']['key'])) {
                    $value = $field['value'][$field_key] ?? '';
                    break;
                  }
                }
              }

              $ordered_fields[$field_key] = [
                'name' => sanitize_title($segment),
                'type' => $field_props['type'] ?? 'number',
                'title' => $field_ui['ui:i18n']['label'][$lang] ?? '',
                'description' => $ui_schema[$field_key]['ui:i18n']['description'][$lang] ?? $field_props['description'] ?? '',
                'required' => in_array($field_key, $schema_data['required'] ?? []),
                'widget_type' => 'number',
                'value' => $value
              ];
            }
          }

          // Convert the ordered fields to a numerically indexed array while preserving order
          $result['fields'] = array_values($ordered_fields);
        }

        return $result;
      }
    }
  }

  return false;
}

function wicket_orgman_business_info_header($org_id, $lang)
{
  $org_info = wicket_orgman_get_organization_info_extended($org_id, $lang);

  if (!$org_info) {
    return false;
  }

?>
  <div class="wicket-welcome-block bg-light-010 rounded-100 p-4 mb-4">
    <h2 class='organization_name heading-lg font-weight:400 dark-100'>
      <?php echo $org_info['org_name'] ?>
    </h2>

    <?php if (!empty($org_info['org_meta']['main_address'])) : ?>
      <p class='formatted_address_label mb-4'>
        <?php echo $org_info['org_meta']['main_address']['formatted_address_label']; ?>
      </p>

      <?php if (isset($org_info['org_meta']['main_email']['address'])) : ?>
        <p class="email_address mb-4">
        <h5 class="font-bold">
          <?php _e('Email Address', 'wicket-acc') ?>
        </h5>
        <?php echo $org_info['org_meta']['main_email']['address'] ?>
        </p>
      <?php endif; ?>

      <?php if (isset($org_info['org_meta']['main_phone']['number_international_format'])) : ?>
        <p class="phone_number mb-4">
        <h5 class="font-bold">
          <?php _e('Phone Number', 'wicket-acc') ?>
        </h5>
        <?php echo $org_info['org_meta']['main_phone']['number_international_format']; ?>
        </p>
      <?php endif; ?>
    <?php endif; ?>
  </div>
<?php
}

/**
 * Renders an additional info section
 *
 * @param string $section_slug The section slug
 * @param array $section_data Array containing section information and fields
 * @param bool $show_no_info Whether to show "No information found" message when empty
 *
 * @return void Echoes the HTML
 */
function wicket_orgman_render_additional_info_section($section_slug, $section_data, $show_no_info = true)
{
  global $orgman_business_info_values_map, $orgman_business_info_section_key_map;

  $section = $section_data['section'] ?? [];
  $fields = $section_data['fields'] ?? [];
  $pre_checked = $section_data['pre_checked_options'] ?? [];

  if (empty($fields) || !is_array($fields)) {
    if ($show_no_info) {
      echo '<p class="text-muted">' . esc_html__('No information found.', 'wicket-acc') . '</p>';
    }
    return;
  }

  $title = $section['title'] ?? '';
  $description = $section['description'] ?? '';
?>
  <div class="section my-3">
    <?php wicket_orgman_render_section_header($title, $description); ?>

    <div class="section__content mt-3 mb-4">
      <?php
      foreach ($fields as $field):
        $name = $field['name'] ?? '';
        $field_title = $field['title'] ?? '';
        $field_description = $field['description'] ?? '';
        $widget_type = $field['widget_type'] ?? 'text';
        $options = $field['options'] ?? [];
        $required = $field['required'] ?? false;
        $value = $field['value'] ?? '';
        $text_value = $field['text_value'] ?? '';
        if (empty($value) && !empty($text_value)) {
          $value = $text_value;
        }

        // Get the schema key from the section data
        $schema_key = $section['schema_key'] ?? '';

        // For operational status fields, use the field index to determine which field it is
        if ($schema_key === 'orgopstatus') {
            $field_keys = ['companyop', 'currentcanada'];
            $field_index = array_search($field, $fields);
            if ($field_index !== false && isset($field_keys[$field_index])) {
                $name = $field_keys[$field_index];
            }
        }

        // Legal name field
        if ($schema_key === 'orglegalname') {
            $name = 'legalname';
        }

        // Number of employees fields
        if ($schema_key === 'orgnumemp') {
            $field_keys = ['numemp'];
            $field_index = array_search($field, $fields);
            if ($field_index !== false && isset($field_keys[$field_index])) {
                $name = $field_keys[$field_index];
            }
        }

        // Retail presence fields
        if ($schema_key === 'orgretailpres') {
            $field_keys = ['presencetype', 'numlocations'];
            $field_index = array_search($field, $fields);
            if ($field_index !== false && isset($field_keys[$field_index])) {
                $name = $field_keys[$field_index];
            }
        }

        // For revenue fields, set specific field names
        if ($schema_key === 'orgrevenue') {
            if (stripos($field_title, 'canadian') !== false || stripos($field_title, 'wellness') !== false) {
                $name = 'totalcdnrev';
            } elseif (stripos($field_title, 'global') !== false) {
                $name = 'totalglobrev';
            }
        }

        // For number of employees field, check pre_checked options
        $select_value = '';
        if ($schema_key === 'orgnumemp') {
          foreach ($pre_checked as $option) {
            if (strpos($option, 'orgnumemp|numemp:') === 0) {
              $select_value = str_replace('orgnumemp|numemp:', '', $option);
              break;
            }
          }
        }

        // Use textarea for orglegalname schema
        if (isset($section['schema_key']) && $section['schema_key'] === 'orglegalname') {
          $widget_type = 'textarea';
        }

        if ($widget_type === 'radio' || $widget_type === 'checkbox'):
          if ($field_title): ?>
            <div class="field-title mb-2">
              <?php echo esc_html($field_title); ?>
              <?php if ($required): ?>
                <span class="required">*</span>
              <?php endif; ?>
            </div>
          <?php endif;

          if ($field_description): ?>
            <p class="field-description mb-2"><?php echo esc_html($field_description); ?></p>
          <?php endif;

          foreach ($options as $option_value => $label):
            $input_type = $widget_type;
            $input_class = 'form-check-input';

            // Get the section prefix from the name (everything before the first colon)
            $name_parts = explode(':', $name);
            $section_prefix = $name_parts[0];

            // We need to map the section prefix to the API value from $orgman_business_info_section_key_map
            $api_section_prefix = $orgman_business_info_section_key_map[$section_prefix] ?? $section_prefix;
            if (empty($api_section_prefix)) {
              $api_section_prefix = $section_prefix;
            }

            // Get the API value from the form value using reverse mapping
            $api_value = array_search($option_value, $orgman_business_info_values_map);
            $api_value_original = '';
            if ($api_value === false) {
              // If not found in the mapping, use the option value as is
              $api_value_original = $api_value;
              $api_value = $option_value;
            }

            // Radio? HERE
            if ($input_type === 'radio') {
              $text_value = $option_value;
              $api_value = $option_value;
            }

            // Build the check value in the format that matches pre_checked array
            $check_value = $api_section_prefix . ':' . $api_value;

            // Check if this value exists in pre_checked
            $is_checked = in_array($check_value, $pre_checked) ? 'checked' : '';

            ?>
            <div class="form-check mb-3">
              <label class="form-check-label d-flex align-items-center">
                <input type="<?php echo esc_attr($input_type); ?>"
                  class="<?php echo esc_attr($input_class); ?><?php if (strtolower($label) === 'other') echo ' other-checkbox'; ?>"
                  name="<?php echo esc_attr($name); ?><?php echo $widget_type === 'radio' ? '' : '[]'; ?>"
                  value="<?php echo esc_attr($api_value); ?>"
                  <?php echo $is_checked; ?>>
                <span><?php echo esc_html($label); ?></span>
              </label>
              <?php if (strtolower($label) === 'other'): ?>
                <div class="other-field <?php echo empty($text_value) ? 'acc-hidden' : ''; ?> mt-2">
                  <input type="text"
                    class="form-control"
                    name="<?php echo esc_attr($name . '_other'); ?>"
                    value="<?php echo esc_attr($text_value); ?>"
                    placeholder="<?php esc_attr_e('Please specify', 'wicket-acc'); ?>">
                </div>
              <?php endif; ?>
            </div>
          <?php endforeach;
        elseif ($widget_type === 'text' || $widget_type === 'readonly'):
          wicket_orgman_render_business_info_field($field_title, $value, false);
        elseif ($widget_type === 'textarea'): ?>
          <?php if ($field_title): ?>
            <div class="field-title mb-2">
              <?php echo esc_html($field_title); ?>
              <?php if ($required): ?>
                <span class="required text-danger">*</span>
              <?php endif; ?>
            </div>
          <?php endif;
          if ($field_description): ?>
            <p class="field-description text-muted mb-2"><?php echo esc_html($field_description); ?></p>
          <?php endif; ?>
          <textarea
            id="<?php echo esc_attr($name); ?>"
            class="form-control w-full"
            name="<?php echo esc_attr($name); ?>"
            rows="3"
            <?php echo $required ? 'required' : ''; ?>><?php echo esc_textarea($value); ?></textarea>
        <?php elseif ($widget_type === 'select'): ?>
          <?php if ($field_title): ?>
            <div class="field-title mb-2">
              <?php echo esc_html($field_title); ?>
              <?php if ($required): ?>
                <span class="required text-danger">*</span>
              <?php endif; ?>
            </div>
          <?php endif;
          if ($field_description): ?>
            <p class="field-description text-muted mb-2"><?php echo esc_html($field_description); ?></p>
          <?php endif; ?>
          <select
            id="<?php echo esc_attr($name); ?>"
            class="form-control w-full"
            name="<?php echo esc_attr($name); ?>"
            <?php echo $required ? 'required' : ''; ?>>
            <option value=""><?php esc_html_e('Select an option', 'wicket-acc'); ?></option>
            <?php foreach ($options as $value => $label):
              $selected = (string) $value === (string) $select_value ? 'selected' : '';
            ?>
              <option value="<?php echo esc_attr($value); ?>" <?php echo $selected; ?>><?php echo esc_html($label); ?></option>
            <?php endforeach; ?>
          </select>
        <?php elseif ($widget_type === 'number'): ?>
          <?php if ($field_title): ?>
            <div class="field-title mb-2">
              <?php echo esc_html($field_title); ?>
              <?php if ($required): ?>
                <span class="required text-danger">*</span>
              <?php endif; ?>
            </div>
          <?php endif;
          if ($field_description): ?>
            <p class="field-description text-muted mb-2"><?php echo esc_html($field_description); ?></p>
          <?php endif; ?>
          <input
            type="number"
            id="<?php echo esc_attr($name); ?>"
            class="form-control w-full"
            name="<?php echo esc_attr($name); ?>"
            value="<?php echo esc_attr($value); ?>"
            min="0"
            <?php echo $required ? 'required' : ''; ?>>
      <?php endif;
      endforeach; ?>
    </div>
  </div>
<?php
}

/**
 * Renders the business categories section
 *
 * @param string $title The section title
 * @param string $description The section description
 * @param array $categories Array of category sections
 *
 * @return void Echoes the HTML
 */
function wicket_orgman_render_business_categories($title, $description, $categories)
{
?>
  <div class="section my-3">
    <?php wicket_orgman_render_section_header($title, $description); ?>

    <div class="section__content mt-3 mb-4">
      <?php
      if (empty($categories)) {
        echo '<p class="text-muted">' . esc_html__('No information found.', 'wicket-acc') . '</p>';
        return;
      }

      foreach ($categories as $category) {
        wicket_orgman_render_additional_info_section('category', $category);
      }
      ?>
    </div>
  </div>
<?php
}

/**
 * Renders a business information field
 *
 * @param string $label The field label
 * @param string $value The field value
 * @param bool $is_subtitle Whether this is a subtitle field
 *
 * @return void Echoes the HTML
 */
function wicket_orgman_render_business_info_field($label, $value, $is_subtitle = false)
{
  if (empty($value)) {
    return;
  }
?>
  <div class="business-info-field mb-4">
    <div class="<?php echo $is_subtitle ? 'h5 mb-1' : 'text-muted small mb-1'; ?>">
      <?php echo esc_html($label); ?>
    </div>
    <div class="<?php echo $is_subtitle ? 'h4' : ''; ?>">
      <?php echo esc_html($value); ?>
    </div>
  </div>
<?php
}

/**
 * Renders a section header
 *
 * @param string $title The section title
 * @param string $description The section description
 *
 * @return void Echoes the HTML
 */
function wicket_orgman_render_section_header($title, $description = '')
{
  // Transform double underscores into strong tags in description
  if (!empty($description)) {
    $description = preg_replace('/__(.*?)__/', '<strong>$1</strong>', $description);
  }
?>
  <div class="section__header">
    <h3 class="section__title my-2"><?php echo esc_html($title); ?></h3>
  </div>
  <?php if ($description): ?>
    <p class="section__description m-2"><?php echo wp_kses($description, ['strong' => []]); ?></p>
  <?php endif; ?>
<?php
}

/**
 * Redirects to the referrer page with the given data, or dies if data is empty or has an error.
 *
 * @param array $data The data to pass to the redirect page.
 * @param array $args The arguments to pass to the redirect page.
 *                  Values: 'action', 'action_type'.
 *                  action_type: success, info, warning, error
 *
 * @return void
 */
function wicket_orgman_redirect_or_die($response = [], $args = [])
{
  if (empty($response)) {
    wp_die(__('No data provided', 'wicket-acc'));
  }

  if (isset($response['error']) && $response['error'] === true) {
    wp_die($response['message']);
  }

  // Redirect
  global $wp;

  $url_redirect  = home_url(add_query_arg([], $wp->request));
  $org_id        = isset($_REQUEST['org_id']) ? sanitize_text_field($_REQUEST['org_id']) : '';
  $membership_id = isset($_REQUEST['membership_id']) ? sanitize_text_field($_REQUEST['membership_id']) : '';
  $included_id   = isset($_REQUEST['included_id']) ? sanitize_text_field($_REQUEST['included_id']) : '';

  $extra_url_params = [
    'action'      => $args['action'] ?? 'none',
    'action_type' => $args['action_type'] ?? 'info',
  ];

  header("Location: $url_redirect?org_id=$org_id&membership_id=$membership_id&included_id=$included_id&" . http_build_query($extra_url_params));

  die();
}

/**
 * Checks if the given response is empty or has an error, and if so, dies with an appropriate message.
 * If the response is valid, it simply returns, allowing the user to continue.
 *
 * @param array $response The data to check.
 */
function wicket_orgman_continue_or_die($response = [])
{
  if (empty($response)) {
    wp_die(__('No data provided', 'wicket'));
  }

  if (isset($response['error']) && $response['error'] === true) {
    wp_die($response['message']);
  }

  // We just let the user continue
  return;
}

/**
 * Assigns a person to an organization membership.
 *
 * @param int|string $person_id The ID of the person to assign.
 * @param int|string $included_id The ID of the included person to assign.
 * @param int|string $org_membership_id The ID of the organization membership to assign to.
 * @param array $org_membership The organization membership to assign to.
 *
 * @return array The response from the MDP API.
 */
function wicket_orgman_assign_person_to_org_membership($person_id = null, $included_id = null, $org_membership_id = null, $org_membership = null)
{
  if (empty($person_id) || empty($included_id) || empty($org_membership_id) || empty($org_membership)) {
    return false;
  }

  $response = wicket_assign_person_to_org_membership((string) $person_id, (string) $included_id, (string) $org_membership_id, (array) $org_membership);

  return $response;
}

/**
 * Assigns the given roles to the given person in the given organization.
 *
 * @param int|string $person_id The UUID of the person to assign roles to.
 * @param array|string $roles The roles to assign. Can be a string or an array of roles.
 * @param int|string $org_id The ID of the organization to assign roles in.
 *
 * @return bool True if successful, false if not.
 */
function wicket_orgman_assign_roles($person_id = null, $roles = [], $org_id = null)
{
  if (empty($person_id) || empty($roles) || empty($org_id)) {
    return false;
  }

  if (!is_array($roles)) {
    $roles = [$roles];
  }

  foreach ($roles as $role) {
    wicket_assign_role($person_id, $role, $org_id);
  }

  return true;
}

/**
 * Removes the given roles from a person in an organization.
 *
 * @param int|string $person_id The ID of the person to remove roles from.
 * @param array|string $roles The roles to remove. Can be a string or an array.
 * @param int|string $org_id The ID of the organization to remove roles from.
 *
 * @return bool True if successful, false if not.
 */
function wicket_orgman_remove_roles($person_id = null, $roles = [], $org_id = null)
{
  if (empty($person_id) || empty($roles) || empty($org_id)) {
    return false;
  }

  // Comma separated?
  if (strpos($roles, ',') !== false) {
    $roles = explode(',', $roles);
  }

  if (!is_array($roles)) {
    $roles = [$roles];
  }

  foreach ($roles as $role) {
    // Never remove: super_admin,administrator,user
    if (in_array($role, ['super_admin', 'administrator', 'user'])) {
      continue;
    }

    wicket_remove_role($person_id, $role, $org_id);
  }

  return true;
}

/**
 * Undo the given connections by removing them.
 *
 * @param int|string|array $connections_id The ID(s) of the connections to undo.
 *
 * @return bool True if successful, false if not.
 */
function wicket_orgman_undo_connections($connections_id = [])
{
  if (empty($connections_id)) {
    return false;
  }

  // Comma separated?
  if (strpos($connections_id, ',') !== false) {
    $connections_id = explode(',', $connections_id);
  }

  if (!is_array($connections_id)) {
    $connections_id = [$connections_id];
  }

  foreach ($connections_id as $connection_id) {
    $response = wicket_remove_connection($connection_id);
  }

  return $response;
}

/**
 * Returns an array of child organizations for the given organization UUID.
 *
 * @param string $org_uuid The UUID of the organization to get child organizations of.
 *
 * @return array|bool An array of child organizations or false if not found.
 */
function wicket_orgman_get_child_organizations($org_uuid = null)
{
  if (!$org_uuid) {
    return false;
  }

  $client       = WACC()->MdpApi->init_client();
  $query_params = [
    'filter' => [
      'with_parent_uuid' => $org_uuid,
    ],
  ];

  $child_orgs = $client->get('/organizations/?' . http_build_query($query_params));

  if (!$child_orgs) {
    return false;
  }

  return $child_orgs;
}

/**
 * Detect if it's a template-partials request
 *
 * @return bool
 */
function wicket_orgman_isTemplatePartialsRequest()
{
  return str_contains($_SERVER['REQUEST_URI'], '/htmx/');
}

/**
 * Load a template partial
 *
 * Like: https://localhost/htmx/?to=account-centre/org-management/subsidiaries-xls-upload&args={}
 *
 * @return void
 */
function wicket_orgman_loadTemplatePartialFromTheme()
{
  // Not a partial request
  if (!wicket_orgman_isTemplatePartialsRequest()) {
    return;
  }

  // Parse the URL
  $urlParts = parse_url($_SERVER['REQUEST_URI']);

  // Find the position of 'htmx/' in the path
  $pos = strpos($urlParts['path'], 'htmx/');

  // No 'htmx/' in the path
  if ($pos === false) {
    return;
  }

  // Partial to load
  $paramLoad = $_GET['to'] ?? '';

  // No partial to load
  if (empty($paramLoad)) {
    wp_die(__('To where?', 'wicket'));
    exit;
  }

  // Avoid directory traversal
  if (str_contains($paramLoad, '..')) {
    return;
  }

  $partial     = sanitize_text_field($paramLoad);
  $args        = $_GET['args'] ?? '';
  $partialPath = get_stylesheet_directory() . '/templates-wicket/partials/' . $partial . '.htmx.php';

  if (file_exists($partialPath)) {
    if (!headers_sent()) {
      http_response_code(200);
    }
    require_once $partialPath;
    exit;
  } else {
    if (!headers_sent()) {
      http_response_code(200);
    }
    wp_die(__('Template partial not found.', 'wicket'));
    exit;
  }
}
add_action('after_setup_theme', 'wicket_orgman_loadTemplatePartialFromTheme', 1);

/**
 * Returns the URL for the Wicket HTMX endpoint.
 *
 * This function returns the home URL with 'htmx' appended to the end.
 *
 * @return string The URL for the Wicket HTMX endpoint.
 */
function wicket_orgman_htmx_url()
{
  return home_url('htmx/');
}

/**
 * Reads a CSV file and returns an array of the data.
 *
 * @param string $filename The path to the CSV file to read.
 *
 * @return array The data from the CSV file.
 */
function wicket_orgman_readCSV($filename)
{
  $transientName = 'wicket_orgman_csv_' . md5($filename);
  $data = get_transient($transientName);

  if ($data === false) {
    if (file_exists($filename)) {
      if (($handle = fopen($filename, "r")) !== FALSE) {
        // Skip header row
        fgetcsv($handle);
        while (($row = fgetcsv($handle)) !== FALSE) {
          $data[] = $row;
        }
        fclose($handle);
      }
    } else {
      // File doesn't exist, return an empty array
      $data = [];
    }

    if (!empty($data)) {
      set_transient($transientName, $data, DAY_IN_SECONDS * 30);
    }
  }

  return $data;
}

/**
 * Delete an Organization from MDP
 *
 * @param int|string $org_id The UUID of the organization to delete.
 *
 * @return bool True if successful, false if not.
 */
function wicket_orgman_delete_organization($org_id = null)
{
  if (!$org_id) {
    return false;
  }

  $client = WACC()->MdpApi->init_client();

  // Send DELETE request to /organizations/{UUID}
  $response = $client->delete('/organizations/' . $org_id);

  if (!$response) {
    return false;
  }

  return true;
}

/**
 * Returns an array of countries.
 *
 * This function reads a CSV file located at the path `get_stylesheet_directory() . '/custom/countries.csv'`
 * and returns the data as an array. The CSV file is expected to have a header row that will be skipped.
 *
 * @return array An array of countries.
 */
function wicket_orgman_getCountries()
{
  $countries = wicket_orgman_readCSV(get_stylesheet_directory() . '/custom/orgman_countries.csv');

  if (empty($countries)) {
    return false;
  }

  return $countries;
}

/**
 * Returns an array of states/provinces.
 *
 * This function reads a CSV file located at the path `get_stylesheet_directory() . '/custom/provinces.csv'`
 * and returns the data as an array. The CSV file is expected to have a header row that will be skipped.
 *
 * @return array An array of provinces.
 */
function wicket_orgman_getStatesProvinces()
{
  $provinces = wicket_orgman_readCSV(get_stylesheet_directory() . '/custom/orgman_statesprovinces.csv');

  if (empty($provinces)) {
    return false;
  }

  return $provinces;
}

/**
 * Send a PATCH request to update an organization's business information section.
 *
 * @param string $org_id The organization UUID
 * @param array $payload The payload to send in the request
 *
 * @return array|bool The response from the API or boolean false on failure
 */
function wicket_orgman_business_info_send_section_patch($org_id, $payload)
{
  $client = WACC()->MdpApi->init_client();

  try {
    $response = $client->patch("organizations/$org_id", ['json' => $payload]);
    return $response && isset($response['data']);
  } catch (Exception $e) {
    return ['error' => $e->getMessage()];
  }
}

/**
 * Creates an associative array from an array of strings,
 * where the keys are sanitized versions of the strings,
 * and the values are the original strings.
 *
 * @param array $array Array of strings to convert to slugs
 * @param string $section_id Optional section identifier for "other" slugs
 *
 * @return array
 */
function wicket_create_slug_array($array, $section_id = '')
{
  $result = [];
  foreach ($array as $value) {
    $slug = sanitize_title($value);

    // Special handling for "other" slugs
    if ($slug === 'other' && !empty($section_id)) {
      // Create a special key for the frontend that includes the section
      $display_key = "other_" . sanitize_title($section_id);
      // Store the original value and metadata separately
      $result[$display_key] = $value;
      $result['_meta'][$display_key] = [
        'original_slug' => 'other',
        'label' => $value
      ];
    } else {
      $result[$slug] = $value;
    }
  }
  return $result;
}

/**
 * Transforms an API response into a structure that can be used in a field array
 *
 * @param array $section_data The API response
 * @param string $section_name The name of the section
 *
 * @return array|null The transformed data or null if the input is invalid
 */
function wicket_orgman_transform_section_data($section_data, $section_name, $description = '')
{
  if (!$section_data || !isset($section_data['attributes'])) {
    return null;
  }

  $fields = [];
  foreach ($section_data['attributes'] as $value => $label) {
    $field = [
      'name' => sanitize_title($section_name),
      'value' => $value,
      'label' => $label,
      'widget_type' => 'checkbox',
      'options' => [$value => $label]
    ];

    // If this is the "other" field and we have an "other" text value
    if ($value === 'other' && isset($section_data['fields']) && !empty($section_data['fields'])) {
      foreach ($section_data['fields'] as $field_data) {
        if ($field_data['name'] === sanitize_title($section_name) && !empty($field_data['value'])) {
          $field['text_value'] = $field_data['value'];
          break;
        }
      }
    }

    $fields[] = $field;
  }

  return [
    'section' => [
      'title' => $section_name,
      'description' => $description
    ],
    'fields' => $fields,
    'pre_checked_options' => $section_data['pre_checked_options'] ?? []
  ];
}

/**
 * Extract pre-checked attributes from data_fields
 *
 * @param array $response The API response
 *
 * @return array The pre-checked options
 */
function wicket_orgman_get_selected_values($response)
{
  if (!isset($response['data']['attributes'])) {
    return [];
  }

  $pre_checked_options = [];

  foreach ($response['data']['attributes']['data_fields'] as $field) {
    // Company Attributes = orgcompattributes
    if ($field['key'] === 'orgcompattributes' && isset($field['value']['attributes'])) {
      foreach ($field['value']['attributes'] as $attr) {
        $pre_checked_options[] = $field['key'] . ':' . sanitize_title($attr);
      }
    }

    // Certifications = orgcertifications
    if ($field['key'] === 'orgcertifications' && isset($field['value']['certifications'])) {
      foreach ($field['value']['certifications'] as $cert) {
        $pre_checked_options[] = $field['key'] . ':' . sanitize_title($cert);
      }
    }

    // Business Services = orgbusservice
    if ($field['key'] === 'orgbusservice' && isset($field['value']['services'])) {
      foreach ($field['value']['services'] as $service) {
        $pre_checked_options[] = $field['key'] . ':' . sanitize_title($service);
      }
    }

    // Product Segments = orgprodsegment
    if ($field['key'] === 'orgprodsegment' && isset($field['value']['prodoptions'])) {
      foreach ($field['value']['prodoptions'] as $prod) {
        $pre_checked_options[] = $field['key'] . ':' . sanitize_title($prod);
      }
    }

    // Retail Presence = orgretailpres
    if ($field['key'] === 'orgretailpres') {
      if (isset($field['value']['presencetype'])) {
        $pre_checked_options[] = 'presencetype:' . sanitize_title($field['value']['presencetype']);
      }
      if (isset($field['value']['numlocations'])) {
        $pre_checked_options[] = 'numlocations:' . sanitize_title($field['value']['numlocations']);
      }
    }

    // Operational Status = orgopstatus
    if ($field['key'] === 'orgopstatus') {
      if (isset($field['value']['companyop'])) {
        $pre_checked_options[] = 'companyop:' . ($field['value']['companyop'] ? 'true' : 'false');
      }
      if (isset($field['value']['currentcanada'])) {
        $pre_checked_options[] = 'currentcanada:' . ($field['value']['currentcanada'] ? 'true' : 'false');
      }
    }

    // Number of Employees = orgnumemp
    if ($field['key'] === 'orgnumemp' && isset($field['value']['numemp'])) {
      $pre_checked_options[] = $field['key'] . '|numemp:' . $field['value']['numemp'];
    }
  }

  return $pre_checked_options;
}

/**
 * Get organization documents
 *
 * @param string $org_id The organization UUID
 *
 * @return array|bool The organization documents or false if not found
 */
function wicket_orgman_get_organization_documents($org_id)
{
  $client = WACC()->MdpApi->init_client();

  /*
   * Get:
   * https://chfa-admin.staging.wicketcloud.com/api/organizations/51f22eea-c473-4400-aa51-685ea957a983?include=addresses%2Cemails%2Cphones%2CwebAddresses%2Croles%2Ccomments%2CpinnedComments.person%2CjsonSchemasAvailable%2CparentOrganization
   **/

   try {
     $response = $client->get("organizations/$org_id?include=addresses,emails,phones,webAddresses,roles,comments,pinnedComments.person,jsonSchemasAvailable,parentOrganization");

     if(isset($response['data']) && !empty($response['data'])) {
       $org_docs = wicket_get_field_from_data_fields($response['data']['attributes']['data_fields'], 'orgmemberdocs')['value'];

       if (!empty($org_docs)) {
         return $org_docs;
       }
     }

     return false;
    } catch (Exception $e) {
     return ['error' => $e->getMessage()];
   }
}

/**
 * Redirects to the correct business edit page
 * Depending of business type.
 * Retailer: https://localhost/my-account/organization-business-information-retail/?org_id=51f22eea-c473-4400-aa51-685ea957a983
 * Any other: https://localhost/my-account/organization-business-information/?org_id=4a1534aa-16a8-4ce9-99b5-d81bad2e1140
 *
 * Redirect account for headers already sent.
 *
 * @param string $org_id The organization UUID
 *
 * @return void
 */
function wicket_orgman_business_edit_redirect($org_id) {
  $org       = wicket_get_organization($org_id);
  $final_url = '';

  if ($org) {
    // Business type
    $org_type = $org['data']['attributes']['type'];

    if ($org_type === 'retailer') {
      $final_url = '/my-account/organization-business-information-retail/?org_id=' . $org_id;
    } else {
      $final_url = '/my-account/organization-business-information/?org_id=' . $org_id;
    }
  }

  // We don't have a final url
  if(empty($final_url)) {
    return;
  }

  // Before redirect the user, we need to ensure if we aren't already in the final url, to avoid an infinite loop
  if (strpos($_SERVER['REQUEST_URI'], $final_url) !== false) {
    return;
  }

  $final_url = home_url($final_url);

  if(!headers_sent()) {
    header('Location: ' . $final_url); }
  else {
    echo '<meta http-equiv="refresh" content="0; url=' . $final_url . '" />';
  }

  die;
}

/**
 * Get display name from schema enum value
 *
 * @param array  $included_schemas Array of included schemas from API response
 * @param string $schema_key      Schema key or UUID to search for (e.g. 'orgclasssubcat' or 'urn:uuid:...')
 * @param string $property_path   Property path in schema (e.g. 'orgtypesubcat')
 * @param string $enum_value      Value to get display name for
 * @param string $lang           Language code (en/fr)
 * @param array  $data_field     Optional data field containing the full value object for "other" cases
 * @return string|null          Display name if found, null otherwise
 */
function wicket_orgman_get_schema_display_name($included_schemas, $schema_key, $property_path, $enum_value, $lang, $data_field = null) {
  if (!$enum_value) {
      return null;
  }

  // Handle "other" case with custom text
  if ($enum_value === 'other' && $data_field !== null) {
      $other_field = $property_path . 'other';
      $other_text = $data_field['value'][$other_field] ?? null;
      if ($other_text) {
          // Get the display name for "Other" from schema
          $other_display = _wicket_orgman_get_enum_display_name($included_schemas, $schema_key, $property_path, 'other', $lang);
          return '(' . $other_display . ') ' . $other_text;
      }
  }

  return _wicket_orgman_get_enum_display_name($included_schemas, $schema_key, $property_path, $enum_value, $lang);
}

/**
 * Helper function to get display name from schema enum value
 *
 * @param array  $included_schemas Array of included schemas from API response
 * @param string $schema_key      Schema key or UUID to search for (e.g. 'orgclasssubcat' or 'urn:uuid:...')
 * @param string $property_path   Property path in schema (e.g. 'orgtypesubcat')
 * @param string $enum_value      Value to get display name for
 * @param string $lang           Language code (en/fr)
 * @return string|null          Display name if found, null otherwise
 */
function _wicket_orgman_get_enum_display_name($included_schemas, $schema_key, $property_path, $enum_value, $lang) {
  // Check if schema_key is a UUID
  $is_uuid = strpos($schema_key, 'urn:uuid:') === 0;

  $schema = array_filter($included_schemas, function($item) use ($schema_key, $is_uuid) {
      if ($is_uuid) {
          return isset($item['attributes']['schema']['$id']) && $item['attributes']['schema']['$id'] === $schema_key;
      }
      return isset($item['attributes']['key']) && $item['attributes']['key'] === $schema_key;
  });

  if ($schema) {
      $schema = current($schema);
      $enum_names = $schema['attributes']['ui_schema'][$property_path]['ui:i18n']['enumNames'][$lang] ?? [];
      $enum_values = $schema['attributes']['schema']['properties'][$property_path]['enum'] ?? [];

      $index = array_search($enum_value, $enum_values);
      if ($index !== false && isset($enum_names[$index])) {
          return $enum_names[$index];
      }
  }

  return null;
}

/**
 * Gets the role usage for a specific role and organization uuid
 *
 * @param string $role
 * @param string $org_id
 *
 * @return mixed person email if used, false otherwise
 */
function wicket_orgman_is_role_used($role = '', $org_id = '') {
  if(empty($role) || empty($org_id)) {
    return false;
  }

  $option_role   = sanitize_title($role);
  $option_org_id = sanitize_title($org_id);

  $result = get_option('_wicket_orgman_role_usage_' . $option_role . '_' . $option_org_id, false);

  if ($result) {
    // It's WP user_id
    return $result;
  }

  return false;
}

/**
 * Gets the organization owner
 *
 * @param string $org_id Organization uuid
 *
 * @return array Organization owner
 */
function wicket_orgman_get_organization_owner($org_id) {
  if (!$org_id) {
    return null;
  }

  $client   = WACC()->MdpApi->init_client();
  $orgOwner = null;

  try {
    $organization_memberships = $client->get("/organizations/$org_id/membership_entries?sort=-ends_at&include=membership%2Cfusebill_subscription%2Cowner");

    if (!isset($organization_memberships['data']) || empty($organization_memberships['data'])) {
      $orgOwner = null;
    }

    // Find the active membership
    foreach ($organization_memberships['data'] as $membership) {
      // Check if membership is active
      if (
        isset($membership['attributes']['active']) &&
        $membership['attributes']['active'] === true &&
        isset($membership['relationships']['owner']['data']['id'])
      ) {
        $orgOwner = $membership['relationships']['owner']['data']['id'];
      }
    }

    // If no active membership found, return the owner of the most recent membership
    if (isset($organization_memberships['data'][0]['relationships']['owner']['data']['id'])) {
      $orgOwner = $organization_memberships['data'][0]['relationships']['owner']['data']['id'];
    }
  } catch(\Exception $e) {
    return null;
  }

  return $orgOwner ? wicket_get_person_by_id($orgOwner) : null;
}
